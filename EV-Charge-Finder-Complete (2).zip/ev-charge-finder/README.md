# EV Charge Finder (Pune) ⚡

**EV Charge Finder** is a modern, responsive web application designed to help electric vehicle commuters in Pune locate nearby charging hubs, check community-reported availability, inspect connector types, and navigate with turn-by-turn routing via OpenStreetMap.

Developed as an Academic Capstone Project at **Marathwada Mitra Mandal's College of Engineering (MMCOE)**, Karve Nagar, Pune.

---

## 🚀 Quick Start & How to Run

### Prerequisites
- Node.js (v18 or higher recommended)
- npm

### 1. Install Dependencies
```bash
npm install
```

### 2. Start Local Development Server
```bash
npm run dev
```

Open your browser at:
**[http://localhost:3000/](http://localhost:3000/)**

### 3. Build for Production
```bash
npm run build
```

---

## 📁 Project Structure

```
ev-charge-finder/
├── index.html                   # HTML entry point with SEO metadata & OpenGraph tags
├── package.json                 # Project configuration & npm scripts
├── vite.config.js               # Vite bundler configuration
├── public/
│   └── favicon.svg              # Green bolt charging favicon
└── src/
    ├── main.jsx                 # React root renderer
    ├── App.jsx                  # Main application orchestrator & state sync
    ├── index.css                # Premium design system (Green, White & Charcoal)
    ├── App.css                  # Component style overrides
    ├── data/
    │   └── stations.js          # Pune EV charging stations demo dataset & seed reviews
    ├── utils/
    │   ├── geoUtils.js          # Haversine distance & OpenStreetMap directions builder
    │   └── storageUtils.js      # Browser localStorage helpers for community reports
    ├── components/
    │   ├── Navbar.jsx           # Responsive header with mobile drawer navigation
    │   ├── Footer.jsx           # MMCOE academic credits, team members, disclaimer
    │   ├── StationCard.jsx      # Station card with badges, ratings, and actions
    │   ├── StationMap.jsx       # Interactive Leaflet map with custom SVG pins & popups
    │   ├── SearchFilters.jsx    # Search input, multi-criteria filters, & geolocation
    │   └── StationDetailModal.jsx # Full station specifications, facilities & reports
    └── pages/
        ├── Home.jsx             # Hero banner, quick search, feature cards & demo spots
        ├── FindChargers.jsx     # Split view layout with map & scrollable station list
        ├── Community.jsx        # Verified feedback form, star ratings, localStorage feed
        └── About.jsx            # Problem statement, objectives, findings & team list
```

---

## 🔍 How to Test Each Feature

1. **Home Page**:
   - Check the hero banner: *"Find Your Next Charge. Drive Without Worry."*
   - Type an area like `"Warje"` into the hero search input and press Enter to jump directly to filtered results.
   - Click **"Find Chargers"** or **"Explore Map"** to navigate smoothly.
   - Explore the 4 feature cards: *Nearby Chargers*, *Smart Filters*, *Community Updates*, *Easy Navigation*.
   - Check the featured demonstration stations (Tata Power Warje, Public Fast Charger Sutar Bldg, Ather Grid AJ Tower).

2. **Find Chargers (Map & Search)**:
   - **Interactive Map**: Pan and zoom around Pune. Click on any colored marker pin (Green = Available, Amber = Occupied, Red = Out of Order) to open the interactive popup.
   - **Search Filter**: Search by name or area (e.g., `"Kothrud"`, `"Baner"`, `"Ather"`, `"Tata"`).
   - **Charger Type Filter**: Switch between `All`, `Fast`, and `Normal`.
   - **Availability Filter**: Filter by `Available`, `Occupied`, or `Out of Order`.
   - **Geolocation & Distance**: Click **"Use My Location"** (or use the simulated **"Simulate MMCOE Location"** button) to calculate exact kilometer distances and sort by closest station.
   - **View Details**: Click **"View Details"** on any card or map popup to inspect connectors, pricing, facilities, operational hours, and volunteer reports in the modal.
   - **Get Directions**: Click **"Directions"** to launch OpenStreetMap turn-by-turn routing directly in a new tab.
   - **Clear Filters**: Click **"Clear Filters"** to restore all defaults.

3. **Community Reports & Persistence**:
   - Navigate to the **Community** tab.
   - Select a station from the dropdown.
   - Choose a status (Available / Occupied / Out of Order).
   - Rate using the 1–5 interactive star picker and enter review feedback.
   - Click **"Submit Report to Community"**.
   - Note the instant confirmation message, live feed update, and persistence across browser refreshes via `localStorage`.

4. **About Project (College Presentation)**:
   - Navigate to **About**.
   - Read the exact problem statement, objectives, and community findings.
   - Inspect the academic details for **MMCOE, Karve Nagar, Pune**, Guide **Mrs. S. P. Vanjari**, and Team Members:
     - Atharv Shyam Jagtap
     - Atharv Vilas Kakade
     - Parthraj Vaibhav Malave
     - Rohan Pravin Patil

---

## 🌐 How to Deploy to Netlify

### Option A: Deploy via Netlify CLI (Fastest)
1. In your project directory, run:
   ```bash
   npm run build
   npx netlify-cli deploy --prod --dir=dist
   ```
2. Follow the prompt to authorize your Netlify account.

### Option B: Deploy via GitHub & Netlify Dashboard
1. Push this directory to your GitHub repository:
   ```bash
   git init
   git add .
   git commit -m "Initial commit of EV Charge Finder"
   git remote add origin https://github.com/your-username/ev-charge-finder.git
   git push -u origin main
   ```
2. Log into [app.netlify.com](https://app.netlify.com/).
3. Click **"Add new site"** → **"Import an existing project"** → Choose **GitHub**.
4. Select `ev-charge-finder`.
5. Netlify will automatically detect Vite settings:
   - **Build command**: `npm run build`
   - **Publish directory**: `dist`
6. Click **"Deploy EV Charge Finder"**. Your site will be live on a secure HTTPS `.netlify.app` domain in seconds!
