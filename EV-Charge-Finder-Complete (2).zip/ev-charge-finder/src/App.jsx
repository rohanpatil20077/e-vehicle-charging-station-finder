import React, { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Home from "./pages/Home";
import FindChargers from "./pages/FindChargers";
import Community from "./pages/Community";
import About from "./pages/About";
import Login from "./pages/Login";
import StationDetailModal from "./components/StationDetailModal";
import { initialStations } from "./data/stations";
import {
  checkBackendStatus,
  getStations,
  getReports,
  postReport,
  getStoredUser
} from "./services/api";

export default function App() {
  const [activePage, setActivePage] = useState("home");
  const [stations, setStations] = useState(initialStations);
  const [communitySubmissions, setCommunitySubmissions] = useState([]);
  const [findSearchQuery, setFindSearchQuery] = useState("");
  const [userLocation, setUserLocation] = useState(null);
  const [detailModalStation, setDetailModalStation] = useState(null);
  const [communityPreselectedStationId, setCommunityPreselectedStationId] = useState(null);
  const [currentUser, setCurrentUser] = useState(() => getStoredUser());

  // Backend status tracking for sensible feedback
  const [backendStatus, setBackendStatus] = useState({
    isOnline: false,
    checked: false,
    service: ""
  });

  // Initial data load & backend health check
  useEffect(() => {
    async function initData() {
      // 1. Check backend status
      const health = await checkBackendStatus();
      setBackendStatus({
        isOnline: health.isOnline,
        checked: true,
        service: health.data?.service || "Express REST Server"
      });

      // 2. Load stations from backend or fallback
      const { stations: loadedStations } = await getStations();
      if (loadedStations && loadedStations.length > 0) {
        setStations(loadedStations);
      }

      // 3. Load reports
      const { reports: loadedReports } = await getReports();
      if (loadedReports && loadedReports.length > 0) {
        setCommunitySubmissions(loadedReports);
      }
    }

    initData();
  }, []);

  // Handle hero search / navigation to Find Chargers page
  const handleNavigateToFind = (query = "") => {
    setFindSearchQuery(query);
    setActivePage("find");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Open community report form with preselected station
  const handleOpenCommunityReport = (stationId) => {
    setCommunityPreselectedStationId(stationId);
    setActivePage("community");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Add a new community submission via backend API
  const handleAddNewSubmission = async (newEntry) => {
    // If user is logged in, attach user metadata
    const enrichedEntry = currentUser
      ? {
          ...newEntry,
          author: `${currentUser.name} (${currentUser.vehicle || "EV Driver"})`,
          userId: currentUser.id
        }
      : newEntry;

    const result = await postReport(enrichedEntry);

    // Refresh reports list
    const { reports: refreshedReports } = await getReports();
    setCommunitySubmissions(refreshedReports);

    // Update stations list
    if (result.updatedStation) {
      setStations((prev) =>
        prev.map((s) => (s.id === result.updatedStation.id ? result.updatedStation : s))
      );
    } else {
      setStations((prev) =>
        prev.map((st) =>
          st.id === newEntry.stationId
            ? { ...st, reportedStatus: newEntry.status, lastUpdated: "Just now" }
            : st
        )
      );
    }
  };

  return (
    <div className="app-root">
      {/* Top Banner with Backend Status & Educational Notice */}
      <div className="top-demo-announcement" role="status">
        <div className="container announcement-inner">
          <span className="announcement-badge">Academic Project</span>
          <span className="announcement-text">
            EV Charge Finder • Developed for MMCOE Karve Nagar, Pune.
          </span>

          {/* Backend Connection Status Badge */}
          <div className="backend-status-pill">
            {backendStatus.isOnline ? (
              <span className="status-online" title="Live Express REST backend is active">
                <span className="live-dot green"></span>
                <span>REST API: Online (Port 5000)</span>
              </span>
            ) : (
              <span className="status-offline" title="Operating with client LocalStorage fallback">
                <span className="live-dot amber"></span>
                <span>Client Mode (LocalStorage)</span>
              </span>
            )}
          </div>

          <button
            type="button"
            className="announcement-link"
            onClick={() => {
              setActivePage("about");
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
          >
            Learn More
          </button>
        </div>
      </div>

      {/* Main Header / Navigation */}
      <Navbar
        activePage={activePage}
        setActivePage={setActivePage}
        currentUser={currentUser}
      />

      {/* Main Page Content */}
      <main className="main-content" id="main-content-area">
        {activePage === "home" && (
          <Home
            stations={stations}
            onNavigateToFind={handleNavigateToFind}
            onViewStationDetails={(st) => setDetailModalStation(st)}
            userLocation={userLocation}
          />
        )}

        {activePage === "find" && (
          <FindChargers
            stations={stations}
            initialSearch={findSearchQuery}
            userLocation={userLocation}
            setUserLocation={setUserLocation}
            onOpenCommunityReport={handleOpenCommunityReport}
            communitySubmissions={communitySubmissions}
          />
        )}

        {activePage === "community" && (
          <Community
            stations={stations}
            communitySubmissions={communitySubmissions}
            onAddNewSubmission={handleAddNewSubmission}
            preselectedStationId={communityPreselectedStationId}
            currentUser={currentUser}
          />
        )}

        {activePage === "login" && (
          <Login
            currentUser={currentUser}
            setCurrentUser={setCurrentUser}
            onNavigate={(page) => {
              setActivePage(page);
              window.scrollTo({ top: 0, behavior: "smooth" });
            }}
          />
        )}

        {activePage === "about" && <About />}
      </main>

      {/* Global Detail Modal */}
      {detailModalStation && (
        <StationDetailModal
          station={detailModalStation}
          onClose={() => setDetailModalStation(null)}
          userLocation={userLocation}
          onOpenCommunityReport={handleOpenCommunityReport}
          communitySubmissions={communitySubmissions}
        />
      )}

      {/* Footer */}
      <Footer setActivePage={setActivePage} />
    </div>
  );
}
