import React, { useState, useMemo, useEffect } from "react";
import StationMap from "../components/StationMap";
import StationCard from "../components/StationCard";
import SearchFilters from "../components/SearchFilters";
import StationDetailModal from "../components/StationDetailModal";
import { calculateDistance } from "../utils/geoUtils";
import { SearchX, RotateCcw, MapPin, Zap, Info, Compass } from "lucide-react";

export default function FindChargers({
  stations,
  initialSearch = "",
  userLocation,
  setUserLocation,
  onOpenCommunityReport,
  communitySubmissions
}) {
  const [searchTerm, setSearchTerm] = useState(initialSearch);
  const [chargerTypeFilter, setChargerTypeFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [maxDistance, setMaxDistance] = useState("All");
  const [sortBy, setSortBy] = useState("default");
  const [selectedStation, setSelectedStation] = useState(null);
  const [modalStation, setModalStation] = useState(null);
  const [isLocating, setIsLocating] = useState(false);
  const [locationError, setLocationError] = useState("");

  // Update searchTerm if initialSearch passed in props changes
  useEffect(() => {
    if (initialSearch) {
      setSearchTerm(initialSearch);
    }
  }, [initialSearch]);

  // Handle Geolocation request
  const handleGetLocation = () => {
    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by your browser.");
      return;
    }

    setIsLocating(true);
    setLocationError("");

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setIsLocating(false);
        setUserLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        });
        setSortBy("nearest");
      },
      (error) => {
        setIsLocating(false);
        let errorMsg = "Unable to retrieve your location.";
        if (error.code === error.PERMISSION_DENIED) {
          errorMsg = "Location permission denied. You can still test with simulated Pune coordinates below.";
        } else if (error.code === error.POSITION_UNAVAILABLE) {
          errorMsg = "Location information is unavailable on your device.";
        } else if (error.code === error.TIMEOUT) {
          errorMsg = "Location request timed out. Please try again.";
        }
        setLocationError(errorMsg);
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  // Helper to simulate location at MMCOE Karve Nagar for testing distance features
  const handleSimulateMMCOELocation = () => {
    setUserLocation({
      latitude: 18.4912,
      longitude: 73.8185
    });
    setLocationError("");
    setSortBy("nearest");
  };

  // Reset all filters
  const handleClearFilters = () => {
    setSearchTerm("");
    setChargerTypeFilter("All");
    setStatusFilter("All");
    setMaxDistance("All");
    setSortBy(userLocation ? "nearest" : "default");
    setLocationError("");
  };

  // Process, filter, calculate distance, and sort stations
  const filteredStations = useMemo(() => {
    return stations
      .map((st) => {
        const distance = userLocation
          ? calculateDistance(
              userLocation.latitude,
              userLocation.longitude,
              st.latitude,
              st.longitude
            )
          : null;
        return { ...st, distance };
      })
      .filter((st) => {
        // Search term matching name, address, area, or description
        if (searchTerm.trim() !== "") {
          const query = searchTerm.toLowerCase().trim();
          const matches =
            st.name.toLowerCase().includes(query) ||
            st.address.toLowerCase().includes(query) ||
            (st.area && st.area.toLowerCase().includes(query)) ||
            (st.description && st.description.toLowerCase().includes(query));
          if (!matches) return false;
        }

        // Charger type filter
        if (chargerTypeFilter !== "All") {
          if (st.chargerType !== chargerTypeFilter) return false;
        }

        // Status filter
        if (statusFilter !== "All") {
          if (st.reportedStatus !== statusFilter) return false;
        }

        // Distance filter (if maxDistance is selected and distance calculated)
        if (maxDistance !== "All" && st.distance != null) {
          const limit = parseFloat(maxDistance);
          if (st.distance > limit) return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === "nearest" && a.distance != null && b.distance != null) {
          return a.distance - b.distance;
        }
        if (sortBy === "rating") {
          return (b.rating || 0) - (a.rating || 0);
        }
        if (sortBy === "points") {
          return (b.totalPoints || 0) - (a.totalPoints || 0);
        }
        return 0; // Default order
      });
  }, [stations, searchTerm, chargerTypeFilter, statusFilter, maxDistance, sortBy, userLocation]);

  return (
    <div className="find-chargers-page" id="find-chargers-view">
      {/* Page Header */}
      <div className="page-header-strip">
        <div className="container">
          <div className="header-breadcrumbs">
            <span>Home</span> / <strong className="active-crumb">Find Chargers</strong>
          </div>
          <div className="header-title-row">
            <div>
              <h1 className="page-title">Find EV Charging Stations in Pune</h1>
              <p className="page-subtitle">
                Explore real-time map locations, check community status reports, and filter by charger speeds.
              </p>
            </div>

            {/* Quick simulated location shortcut for college demonstration */}
            {!userLocation && (
              <button
                type="button"
                className="btn-demo-location"
                onClick={handleSimulateMMCOELocation}
                title="Simulate user location at MMCOE, Karve Nagar to showcase distance sorting"
              >
                <Compass size={15} />
                <span>Simulate MMCOE Location</span>
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="container find-chargers-layout">
        {/* Search & Filter Controls */}
        <SearchFilters
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          chargerTypeFilter={chargerTypeFilter}
          setChargerTypeFilter={setChargerTypeFilter}
          statusFilter={statusFilter}
          setStatusFilter={setStatusFilter}
          maxDistance={maxDistance}
          setMaxDistance={setMaxDistance}
          sortBy={sortBy}
          setSortBy={setSortBy}
          userLocation={userLocation}
          isLocating={isLocating}
          locationError={locationError}
          onGetLocation={handleGetLocation}
          onClearFilters={handleClearFilters}
          totalResults={filteredStations.length}
          totalStations={stations.length}
        />

        {/* Split View Container: Left Sidebar Cards + Right Interactive Map */}
        <div className="chargers-split-view">
          {/* Left Column: Station Cards List */}
          <div className="stations-cards-column" id="stations-list-container">
            {filteredStations.length === 0 ? (
              <div className="no-stations-found">
                <SearchX size={44} className="empty-icon" />
                <h3>No Matching Stations Found</h3>
                <p>
                  No charging stations match your current search and filter selections. Try relaxing
                  your filters or resetting your query.
                </p>
                <button
                  type="button"
                  className="btn-reset-empty"
                  onClick={handleClearFilters}
                >
                  <RotateCcw size={16} />
                  <span>Reset All Filters</span>
                </button>
              </div>
            ) : (
              <div className="stations-scrollable-list">
                {filteredStations.map((station) => (
                  <StationCard
                    key={station.id}
                    station={station}
                    isSelected={selectedStation?.id === station.id}
                    onSelect={(st) => setSelectedStation(st)}
                    onViewDetails={(st) => setModalStation(st)}
                    userLocation={userLocation}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Right Column: Interactive Map */}
          <div className="stations-map-column">
            <div className="map-sticky-wrapper">
              <StationMap
                stations={filteredStations}
                selectedStation={selectedStation}
                onSelectStation={(st) => {
                  setSelectedStation(st);
                  // Scroll matching card into view on small screens
                  const cardElem = document.getElementById(`station-card-${st.id}`);
                  if (cardElem) {
                    cardElem.scrollIntoView({ behavior: "smooth", block: "nearest" });
                  }
                }}
                onViewDetails={(st) => setModalStation(st)}
                userLocation={userLocation}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Detail Modal */}
      {modalStation && (
        <StationDetailModal
          station={modalStation}
          onClose={() => setModalStation(null)}
          userLocation={userLocation}
          onOpenCommunityReport={onOpenCommunityReport}
          communitySubmissions={communitySubmissions}
        />
      )}
    </div>
  );
}
