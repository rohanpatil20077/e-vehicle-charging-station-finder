import React, { useState } from "react";
import {
  LogIn,
  UserPlus,
  KeyRound,
  Mail,
  User,
  Car,
  AlertCircle,
  CheckCircle,
  Sparkles,
  ArrowRight,
  LogOut,
  ShieldCheck,
  Zap
} from "lucide-react";
import { loginUser, registerUser, logoutUser } from "../services/api";

export default function Login({ currentUser, setCurrentUser, onNavigate }) {
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [vehicle, setVehicle] = useState("");

  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  // Submit Handler
  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg("");
    setSuccessMsg("");
    setIsLoading(true);

    try {
      if (isLoginMode) {
        if (!email || !password) {
          throw new Error("Please enter both email and password.");
        }
        const res = await loginUser(email, password);
        setCurrentUser(res.user);
        setSuccessMsg(`Welcome back, ${res.user.name}!`);
      } else {
        if (!name.trim()) throw new Error("Please enter your name.");
        if (!email.trim() || !email.includes("@")) throw new Error("Please enter a valid email address.");
        if (password.length < 6) throw new Error("Password must be at least 6 characters.");

        const res = await registerUser({ name, email, password, vehicle });
        setCurrentUser(res.user);
        setSuccessMsg(`Account created successfully! Welcome, ${res.user.name}.`);
      }
    } catch (err) {
      setErrorMsg(err.message || "Authentication failed. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  // One-click demo login helper
  const handleQuickDemoLogin = async (demoEmail, demoPass) => {
    setErrorMsg("");
    setSuccessMsg("");
    setIsLoading(true);
    try {
      const res = await loginUser(demoEmail, demoPass);
      setCurrentUser(res.user);
      setSuccessMsg(`Logged in as demo user ${res.user.name}!`);
    } catch (err) {
      setErrorMsg(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Logout Handler
  const handleLogout = () => {
    logoutUser();
    setCurrentUser(null);
    setSuccessMsg("You have logged out successfully.");
    setEmail("");
    setPassword("");
  };

  return (
    <div className="login-page-view" id="auth-section">
      {/* Page Header */}
      <div className="page-header-strip">
        <div className="container">
          <div className="header-breadcrumbs">
            <span>Home</span> / <strong className="active-crumb">Account & Driver Portal</strong>
          </div>
          <h1 className="page-title">EV Driver Community Access</h1>
          <p className="page-subtitle">
            Sign in to submit verified station reviews, save preferences, and report charger availability.
          </p>
        </div>
      </div>

      <div className="container auth-layout">
        {currentUser ? (
          /* Profile Card when Logged In */
          <div className="auth-profile-card">
            <div className="profile-badge-strip">
              <span className="profile-role-badge">
                <Sparkles size={14} /> {currentUser.role || "Verified Driver"}
              </span>
              <span className="profile-status-live">● Active Session</span>
            </div>

            <div className="profile-avatar-circle">
              {currentUser.name
                .split(" ")
                .map((n) => n[0])
                .slice(0, 2)
                .join("")}
            </div>

            <h2 className="profile-user-name">{currentUser.name}</h2>
            <p className="profile-user-email">{currentUser.email}</p>

            <div className="profile-details-grid">
              <div className="profile-detail-box">
                <Car size={18} className="text-emerald" />
                <div>
                  <span className="detail-box-label">Registered Vehicle</span>
                  <strong className="detail-box-value">{currentUser.vehicle || "Electric Vehicle"}</strong>
                </div>
              </div>

              <div className="profile-detail-box">
                <ShieldCheck size={18} className="text-emerald" />
                <div>
                  <span className="detail-box-label">Account Security</span>
                  <strong className="detail-box-value">REST API Verified</strong>
                </div>
              </div>
            </div>

            <div className="profile-actions-row">
              <button
                type="button"
                className="btn-profile-primary"
                onClick={() => onNavigate("find")}
              >
                <Zap size={16} />
                <span>Find Nearby Chargers</span>
              </button>

              <button
                type="button"
                className="btn-profile-secondary"
                onClick={() => onNavigate("community")}
              >
                <span>Submit Station Report</span>
                <ArrowRight size={16} />
              </button>

              <button
                type="button"
                className="btn-profile-logout"
                onClick={handleLogout}
              >
                <LogOut size={16} />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        ) : (
          /* Login / Registration Form Card */
          <div className="auth-card-container">
            {/* Tab switch: Sign In vs Sign Up */}
            <div className="auth-mode-tabs">
              <button
                type="button"
                className={`auth-tab-btn ${isLoginMode ? "active" : ""}`}
                onClick={() => {
                  setIsLoginMode(true);
                  setErrorMsg("");
                  setSuccessMsg("");
                }}
              >
                <LogIn size={16} />
                <span>Sign In</span>
              </button>

              <button
                type="button"
                className={`auth-tab-btn ${!isLoginMode ? "active" : ""}`}
                onClick={() => {
                  setIsLoginMode(false);
                  setErrorMsg("");
                  setSuccessMsg("");
                }}
              >
                <UserPlus size={16} />
                <span>Create Account</span>
              </button>
            </div>

            <div className="auth-card-body">
              <div className="auth-form-header">
                <h3>{isLoginMode ? "Sign in to your driver account" : "Join the EV Charge Community"}</h3>
                <p>
                  {isLoginMode
                    ? "Access personalized charger filtering and community contribution."
                    : "Register to share real-time stall updates with fellow Pune EV drivers."}
                </p>
              </div>

              {/* Error / Success Feedback */}
              {errorMsg && (
                <div className="auth-alert error" role="alert">
                  <AlertCircle size={16} />
                  <span>{errorMsg}</span>
                </div>
              )}

              {successMsg && (
                <div className="auth-alert success" role="status">
                  <CheckCircle size={16} />
                  <span>{successMsg}</span>
                </div>
              )}

              <form className="auth-form" onSubmit={handleSubmit}>
                {!isLoginMode && (
                  <>
                    <div className="auth-input-group">
                      <label htmlFor="auth-name" className="auth-label">Full Name</label>
                      <div className="input-with-icon">
                        <User size={16} className="field-icon" />
                        <input
                          id="auth-name"
                          type="text"
                          className="auth-input"
                          placeholder="e.g. Atharv Jagtap"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          required={!isLoginMode}
                        />
                      </div>
                    </div>

                    <div className="auth-input-group">
                      <label htmlFor="auth-vehicle" className="auth-label">EV Model / Vehicle (Optional)</label>
                      <div className="input-with-icon">
                        <Car size={16} className="field-icon" />
                        <input
                          id="auth-vehicle"
                          type="text"
                          className="auth-input"
                          placeholder="e.g. Tata Nexon EV, Ather 450X, MG ZS EV"
                          value={vehicle}
                          onChange={(e) => setVehicle(e.target.value)}
                        />
                      </div>
                    </div>
                  </>
                )}

                <div className="auth-input-group">
                  <label htmlFor="auth-email" className="auth-label">Email Address</label>
                  <div className="input-with-icon">
                    <Mail size={16} className="field-icon" />
                    <input
                      id="auth-email"
                      type="email"
                      className="auth-input"
                      placeholder="driver@evfinder.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <div className="auth-input-group">
                  <label htmlFor="auth-password" className="auth-label">Password</label>
                  <div className="input-with-icon">
                    <KeyRound size={16} className="field-icon" />
                    <input
                      id="auth-password"
                      type="password"
                      className="auth-input"
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                  {!isLoginMode && <small className="input-hint">At least 6 characters required.</small>}
                </div>

                <button
                  type="submit"
                  id="btn-auth-submit"
                  className="btn-auth-submit"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <span>Authenticating...</span>
                  ) : (
                    <>
                      <span>{isLoginMode ? "Sign In" : "Register Account"}</span>
                      <ArrowRight size={16} />
                    </>
                  )}
                </button>
              </form>

              {/* Quick One-Click Demo Logins for Presentations / Examiners */}
              <div className="demo-logins-box">
                <span className="demo-box-title">⚡ Quick Demo Logins (For College Evaluation)</span>
                <div className="demo-buttons-grid">
                  <button
                    type="button"
                    className="btn-demo-quick"
                    onClick={() => handleQuickDemoLogin("driver@evfinder.com", "password123")}
                  >
                    <strong>Atharv Jagtap</strong>
                    <small>driver@evfinder.com (Nexon EV)</small>
                  </button>

                  <button
                    type="button"
                    className="btn-demo-quick"
                    onClick={() => handleQuickDemoLogin("rohan@mmcoe.edu.in", "password123")}
                  >
                    <strong>Rohan Patil</strong>
                    <small>rohan@mmcoe.edu.in (Ather 450X)</small>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
