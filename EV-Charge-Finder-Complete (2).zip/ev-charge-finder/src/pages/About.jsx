import React from "react";
import {
  GraduationCap,
  Users,
  Target,
  AlertCircle,
  Lightbulb,
  CheckCircle2,
  Code2,
  MapPin,
  Layers,
  Sparkles,
  ShieldAlert
} from "lucide-react";

export default function About() {
  const teamMembers = [
    {
      name: "Atharv Shyam Jagtap",
      role: "Team Member",
      dept: "B.E. Information Technology",
      college: "MMCOE, Pune"
    },
    {
      name: "Atharv Vilas Kakade",
      role: "Team Member",
      dept: "B.E. Information Technology",
      college: "MMCOE, Pune"
    },
    {
      name: "Parthraj Vaibhav Malave",
      role: "Team Member",
      dept: "B.E. Information Technology",
      college: "MMCOE, Pune"
    },
    {
      name: "Rohan Pravin Patil",
      role: "Team Member",
      dept: "B.E. Information Technology",
      college: "MMCOE, Pune"
    }
  ];

  const objectives = [
    "Locate nearby EV charging stations.",
    "Show station location, charger type, reported availability, and operating hours.",
    "Help users choose a suitable charging station.",
    "Reduce the time and effort required to find chargers."
  ];

  const findings = [
    "Charging stations are located in public places, parking areas, and commercial locations.",
    "The number of charging points varies by station.",
    "Availability can change over time.",
    "Different charger types have different charging characteristics.",
    "Some stations offer parking, lighting, seating, and basic support."
  ];

  return (
    <div className="about-page-view" id="about-project-view">
      {/* Page Header */}
      <div className="page-header-strip">
        <div className="container">
          <div className="header-breadcrumbs">
            <span>Home</span> / <strong className="active-crumb">About Project</strong>
          </div>
          <h1 className="page-title">About EV Charge Finder</h1>
          <p className="page-subtitle">
            An Academic Capstone Project developed at Marathwada Mitra Mandal's College of
            Engineering (MMCOE), Pune.
          </p>
        </div>
      </div>

      <div className="container about-content-layout">
        {/* Academic Project Card */}
        <section className="academic-meta-card">
          <div className="academic-meta-grid">
            <div className="meta-block">
              <span className="meta-label">Project Title</span>
              <h3 className="meta-value">E-Vehicle Charging Station Finder</h3>
            </div>

            <div className="meta-block">
              <span className="meta-label">Institution</span>
              <h4 className="meta-value">
                Marathwada Mitra Mandal's College of Engineering (MMCOE)
              </h4>
              <p className="meta-sub">Karve Nagar, Pune, Maharashtra - 411052</p>
            </div>

            <div className="meta-block">
              <span className="meta-label">Academic Department</span>
              <h4 className="meta-value">Department of Information Technology</h4>
            </div>

            <div className="meta-block guide-highlight">
              <span className="meta-label">Project Guide</span>
              <h4 className="meta-value">Mrs. S. P. Vanjari</h4>
              <p className="meta-sub">Assistant Professor, Dept of IT</p>
            </div>
          </div>
        </section>

        {/* Problem Statement Card */}
        <section className="about-section-card problem-card">
          <div className="card-badge-header">
            <div className="icon-pill bg-danger-soft">
              <AlertCircle size={20} className="text-danger" />
            </div>
            <div>
              <span className="section-eyebrow text-danger">The Core Challenge</span>
              <h2 className="about-section-heading">Problem Statement</h2>
            </div>
          </div>

          <div className="problem-quote-box">
            <p className="problem-statement-text">
              “EV users lack a single, reliable source that shows nearby charging stations along
              with live availability, charger type and charging time, so they lose time and may
              reach an occupied or unsuitable charger.”
            </p>
          </div>
        </section>

        {/* Project Objectives */}
        <section className="about-section-card">
          <div className="card-badge-header">
            <div className="icon-pill bg-emerald-soft">
              <Target size={20} className="text-emerald" />
            </div>
            <div>
              <span className="section-eyebrow text-emerald">Goals & Intent</span>
              <h2 className="about-section-heading">Project Objectives</h2>
            </div>
          </div>

          <div className="objectives-list-grid">
            {objectives.map((obj, index) => (
              <div key={index} className="objective-item-card">
                <div className="objective-number">{`0${index + 1}`}</div>
                <div className="objective-content">
                  <p>{obj}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Community Engagement Findings */}
        <section className="about-section-card">
          <div className="card-badge-header">
            <div className="icon-pill bg-blue-soft">
              <Lightbulb size={20} className="text-blue" />
            </div>
            <div>
              <span className="section-eyebrow text-blue">Ground Insights</span>
              <h2 className="about-section-heading">Community Engagement Findings</h2>
            </div>
          </div>

          <p className="findings-intro">
            During research and interactions with local EV commuters around Karve Road, Kothrud, and
            Warje, our project identified several critical behavioral and infrastructural realities:
          </p>

          <div className="findings-list">
            {findings.map((item, index) => (
              <div key={index} className="finding-row">
                <CheckCircle2 size={20} className="finding-icon text-emerald" />
                <p className="finding-text">{item}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Project Team Members */}
        <section className="about-section-card team-section">
          <div className="card-badge-header">
            <div className="icon-pill bg-purple-soft">
              <Users size={20} className="text-purple" />
            </div>
            <div>
              <span className="section-eyebrow text-purple">Contributors</span>
              <h2 className="about-section-heading">Project Team Members</h2>
            </div>
          </div>

          <div className="team-cards-grid">
            {teamMembers.map((member, index) => (
              <div key={index} className="team-member-card">
                <div className="avatar-placeholder">
                  {member.name
                    .split(" ")
                    .map((n) => n[0])
                    .slice(0, 2)
                    .join("")}
                </div>
                <h4 className="member-name">{member.name}</h4>
                <span className="member-role">{member.role}</span>
                <span className="member-dept">{member.dept}</span>
                <span className="member-college">{member.college}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Technology Architecture */}
        <section className="about-section-card tech-card">
          <div className="card-badge-header">
            <div className="icon-pill bg-cyan-soft">
              <Code2 size={20} className="text-cyan" />
            </div>
            <div>
              <span className="section-eyebrow text-cyan">Technical Stack</span>
              <h2 className="about-section-heading">Built With Modern Web Standards</h2>
            </div>
          </div>

          <div className="tech-stack-chips">
            <div className="tech-chip">
              <strong>React.js (v19)</strong>
              <span>Component architecture</span>
            </div>
            <div className="tech-chip">
              <strong>Vite</strong>
              <span>Lightning fast build tooling</span>
            </div>
            <div className="tech-chip">
              <strong>Leaflet & React Leaflet</strong>
              <span>Interactive geospatial mapping</span>
            </div>
            <div className="tech-chip">
              <strong>OpenStreetMap</strong>
              <span>Open tile mapping & routing</span>
            </div>
            <div className="tech-chip">
              <strong>Vanilla CSS</strong>
              <span>Clean modern design system</span>
            </div>
            <div className="tech-chip">
              <strong>Browser LocalStorage</strong>
              <span>Persistent community feedback</span>
            </div>
            <div className="tech-chip">
              <strong>Lucide React</strong>
              <span>Crisp accessible iconography</span>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
