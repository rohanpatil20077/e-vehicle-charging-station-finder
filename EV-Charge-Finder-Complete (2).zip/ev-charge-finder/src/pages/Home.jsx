import React, { useState } from "react";
import {
  Zap,
  MapPin,
  Sliders,
  Users,
  Navigation,
  ArrowRight,
  ShieldCheck,
  CheckCircle,
  Clock,
  Sparkles,
  Search,
  ExternalLink
} from "lucide-react";
import StationCard from "../components/StationCard";

export default function Home({
  stations,
  onNavigateToFind,
  onViewStationDetails,
  userLocation
}) {
  const [heroSearchInput, setHeroSearchInput] = useState("");

  const handleHeroSearchSubmit = (e) => {
    e.preventDefault();
    onNavigateToFind(heroSearchInput.trim());
  };

  // Demonstration featured stations required by user
  const featuredStations = stations.filter((s) =>
    ["station-1", "station-2", "station-3"].includes(s.id)
  );

  return (
    <div className="home-page-view">
      {/* Hero Section */}
      <section className="hero-section" id="hero-banner">
        <div className="hero-backdrop-glow"></div>
        <div className="container hero-content">
          <div className="hero-pill-badge">
            <Sparkles size={14} className="sparkle-icon" />
            <span>Smart Electric Vehicle Network • Pune</span>
          </div>

          <h1 className="hero-headline">
            Find Your Next Charge. <br />
            <span className="hero-gradient-text">Drive Without Worry.</span>
          </h1>

          <p className="hero-subtext">
            Never get stranded with an empty battery or occupied bay. Locate EV charging hubs
            across Pune, view community-reported statuses, filter by connector type, and get direct
            routing via OpenStreetMap.
          </p>

          {/* Quick Hero Search Bar */}
          <form className="hero-search-form" onSubmit={handleHeroSearchSubmit}>
            <div className="hero-search-box">
              <Search size={20} className="hero-search-icon" />
              <input
                type="text"
                className="hero-search-input"
                placeholder="Search city, area, or station (e.g. Warje, Kothrud, Tata Power)..."
                value={heroSearchInput}
                onChange={(e) => setHeroSearchInput(e.target.value)}
                aria-label="Search station or area"
              />
              <button type="submit" className="btn-hero-search">
                <span>Search</span>
                <ArrowRight size={16} />
              </button>
            </div>
          </form>

          {/* Primary Action Buttons */}
          <div className="hero-action-buttons">
            <button
              type="button"
              className="btn-primary-hero"
              onClick={() => onNavigateToFind("")}
              id="btn-hero-find-chargers"
            >
              <Zap size={18} />
              <span>Find Chargers</span>
            </button>

            <button
              type="button"
              className="btn-secondary-hero"
              onClick={() => onNavigateToFind("")}
              id="btn-hero-explore-map"
            >
              <Navigation size={18} />
              <span>Explore Map</span>
            </button>
          </div>

          {/* Quick Highlights Strip */}
          <div className="hero-stats-strip">
            <div className="stat-pill">
              <strong className="stat-num">{stations.length}+</strong>
              <span className="stat-label">Stations Listed</span>
            </div>
            <div className="stat-divider"></div>
            <div className="stat-pill">
              <strong className="stat-num">DC Fast & AC</strong>
              <span className="stat-label">Multi-Standard</span>
            </div>
            <div className="stat-divider"></div>
            <div className="stat-pill">
              <strong className="stat-num">Community</strong>
              <span className="stat-label">Volunteer Reports</span>
            </div>
            <div className="stat-divider"></div>
            <div className="stat-pill">
              <strong className="stat-num">Pune Area</strong>
              <span className="stat-label">MMCOE Initiative</span>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Cards Section */}
      <section className="features-section container" id="features-overview">
        <div className="section-title-wrap text-center">
          <span className="section-eyebrow">Key Capabilities</span>
          <h2 className="section-main-heading">Everything You Need For Seamless EV Travel</h2>
          <p className="section-sub-heading">
            Built to tackle range anxiety and charging bay uncertainties with clear community insights.
          </p>
        </div>

        <div className="features-grid">
          {/* Card 1: Nearby Chargers */}
          <div className="feature-card">
            <div className="feature-icon-box bg-emerald">
              <MapPin size={26} className="feature-icon" />
            </div>
            <h3 className="feature-card-title">Nearby Chargers</h3>
            <p className="feature-card-desc">
              Instantly view charging locations relative to your real-time position using browser
              geolocation or browse key Pune corridors like Kothrud, Karve Road, and Hinjawadi.
            </p>
          </div>

          {/* Card 2: Smart Filters */}
          <div className="feature-card">
            <div className="feature-icon-box bg-blue">
              <Sliders size={26} className="feature-icon" />
            </div>
            <h3 className="feature-card-title">Smart Filters</h3>
            <p className="feature-card-desc">
              Narrow down options effortlessly by charger speed (Fast DC vs Normal AC), current
              reported availability, distance range, and user ratings.
            </p>
          </div>

          {/* Card 3: Community Updates */}
          <div className="feature-card">
            <div className="feature-icon-box bg-amber">
              <Users size={26} className="feature-icon" />
            </div>
            <h3 className="feature-card-title">Community Updates</h3>
            <p className="feature-card-desc">
              Rely on fellow EV commuters who report real-world status (Available, Occupied, or Out of
              Order) and leave practical tips on parking, queues, and amenities.
            </p>
          </div>

          {/* Card 4: Easy Navigation */}
          <div className="feature-card">
            <div className="feature-icon-box bg-purple">
              <Navigation size={26} className="feature-icon" />
            </div>
            <h3 className="feature-card-title">Easy Navigation</h3>
            <p className="feature-card-desc">
              Launch directly into OpenStreetMap directions with one click. Get accurate route
              guidance without proprietary gatekeeping or tracking.
            </p>
          </div>
        </div>
      </section>

      {/* Featured Demonstration Stations Section */}
      <section className="featured-stations-section">
        <div className="container">
          <div className="section-header-flex">
            <div>
              <span className="section-eyebrow">Project Demonstration</span>
              <h2 className="section-main-heading">Key Charging Hubs in Pune</h2>
              <p className="section-sub-heading">
                Explore key demo stations tested as part of the MMCOE IT project evaluation.
              </p>
            </div>
            <button
              type="button"
              className="btn-outline-view-all"
              onClick={() => onNavigateToFind("")}
            >
              <span>View All on Interactive Map</span>
              <ArrowRight size={16} />
            </button>
          </div>

          <div className="featured-cards-grid">
            {featuredStations.map((station) => (
              <StationCard
                key={station.id}
                station={station}
                isSelected={false}
                onSelect={(st) => onViewStationDetails(st)}
                onViewDetails={(st) => onViewStationDetails(st)}
                userLocation={userLocation}
              />
            ))}
          </div>
        </div>
      </section>

      {/* How it Works / 3-Step Process */}
      <section className="how-it-works-section container">
        <div className="section-title-wrap text-center">
          <span className="section-eyebrow">Simple Workflow</span>
          <h2 className="section-main-heading">How EV Charge Finder Works</h2>
        </div>

        <div className="steps-container">
          <div className="step-card">
            <div className="step-number">01</div>
            <h4>Search or Enable GPS</h4>
            <p>Locate stations along your destination corridor or detect your live location.</p>
          </div>

          <div className="step-connector"></div>

          <div className="step-card">
            <div className="step-number">02</div>
            <h4>Check Status & Connectors</h4>
            <p>Review community-reported stall availability, port types (CCS2, Type-2), and hours.</p>
          </div>

          <div className="step-connector"></div>

          <div className="step-card">
            <div className="step-number">03</div>
            <h4>Navigate & Contribute</h4>
            <p>Get OpenStreetMap directions, plug in, and post a quick update for other drivers.</p>
          </div>
        </div>
      </section>

      {/* Project Banner / Institutional Callout */}
      <section className="container mb-8">
        <div className="academic-banner-card">
          <div className="academic-banner-content">
            <span className="academic-pill">MMCOE Academic Project</span>
            <h3 className="academic-title">Developed at Marathwada Mitra Mandal's College of Engineering</h3>
            <p className="academic-desc">
              Created by final-year students of the Information Technology Department under the
              guidance of Mrs. S. P. Vanjari to support sustainable urban electric vehicle transit in
              Pune.
            </p>
          </div>
          <button
            type="button"
            className="btn-academic-learn"
            onClick={() => onNavigateToFind("")}
          >
            Explore Pune Stations
          </button>
        </div>
      </section>
    </div>
  );
}
