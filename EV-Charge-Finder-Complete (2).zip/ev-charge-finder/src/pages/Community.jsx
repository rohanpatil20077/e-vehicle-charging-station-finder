import React, { useState, useEffect } from "react";
import {
  Users,
  CheckCircle,
  Clock,
  AlertTriangle,
  Star,
  Send,
  ShieldAlert,
  MessageSquare,
  ThumbsUp,
  Filter,
  Sparkles,
  Check,
  AlertCircle
} from "lucide-react";
import { formatTimestamp } from "../utils/storageUtils";

export default function Community({
  stations,
  communitySubmissions,
  onAddNewSubmission,
  preselectedStationId = null,
  currentUser = null
}) {
  // Form State
  const [stationId, setStationId] = useState(preselectedStationId || "");
  const [authorName, setAuthorName] = useState(
    currentUser ? `${currentUser.name} (${currentUser.vehicle || "EV Driver"})` : ""
  );
  const [reportedStatus, setReportedStatus] = useState("Available");
  const [starRating, setStarRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);
  const [commentText, setCommentText] = useState("");
  const [selectedFilterStation, setSelectedFilterStation] = useState("All");

  // Update authorName if currentUser changes
  useEffect(() => {
    if (currentUser && !authorName) {
      setAuthorName(`${currentUser.name} (${currentUser.vehicle || "EV Driver"})`);
    }
  }, [currentUser]);

  // Feedback alerts
  const [formError, setFormError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  // Update stationId when preselectedStationId changes
  useEffect(() => {
    if (preselectedStationId) {
      setStationId(preselectedStationId);
    }
  }, [preselectedStationId]);

  const handleSubmit = (e) => {
    e.preventDefault();
    setFormError("");
    setSuccessMessage("");

    // Validation
    if (!stationId) {
      setFormError("Please select a charging station from the dropdown.");
      return;
    }

    if (!reportedStatus) {
      setFormError("Please select the current status of the station.");
      return;
    }

    const matchedStation = stations.find((s) => s.id === stationId);
    const stationName = matchedStation ? matchedStation.name : "Station";

    const newEntry = {
      id: `sub-${Date.now()}`,
      stationId,
      stationName,
      author: authorName.trim() || "Anonymous Driver",
      status: reportedStatus,
      rating: starRating,
      comment: commentText.trim(),
      timestamp: formatTimestamp(new Date()),
      verifiedStatus: "Community Reported"
    };

    onAddNewSubmission(newEntry);

    // Show success feedback
    setSuccessMessage(
      `Thank you! Your status report for "${stationName}" has been recorded and saved locally.`
    );

    // Reset inputs
    setCommentText("");
    setAuthorName("");

    // Auto dismiss success toast after 5s
    setTimeout(() => {
      setSuccessMessage("");
    }, 5000);
  };

  // Filter submissions by station
  const filteredSubmissions =
    selectedFilterStation === "All"
      ? communitySubmissions
      : communitySubmissions.filter((item) => item.stationId === selectedFilterStation);

  return (
    <div className="community-page-view" id="community-hub">
      {/* Page Header */}
      <div className="page-header-strip">
        <div className="container">
          <div className="header-breadcrumbs">
            <span>Home</span> / <strong className="active-crumb">Community Network</strong>
          </div>
          <h1 className="page-title">Community Updates & Driver Reports</h1>
          <p className="page-subtitle">
            Contribute local ground realities to keep fellow electric vehicle commuters informed.
            Submissions are saved locally in your browser storage.
          </p>
        </div>
      </div>

      <div className="container community-layout">
        {/* Important Educational & Non-Telemetry Disclaimer */}
        <div className="community-disclaimer-card" role="note">
          <div className="disclaimer-icon-wrap">
            <ShieldAlert size={24} className="disclaimer-icon" />
          </div>
          <div className="disclaimer-content">
            <h4>Notice: Community-Submitted Observations</h4>
            <p>
              Reports below are submitted by visitors and fellow EV drivers. They reflect personal
              experiences, observations, and educational testing for this academic project. They do
              <strong> not</strong> represent automated hardware feeds or guaranteed utility station
              availability.
            </p>
          </div>
        </div>

        <div className="community-grid">
          {/* Left Column: Submission Form */}
          <div className="community-form-card">
            <div className="form-card-header">
              <div className="badge-chip">
                <Sparkles size={14} /> Contribute
              </div>
              <h2 className="form-card-title">Report Station Status & Review</h2>
              <p className="form-card-desc">
                Visited a charger recently? Share port availability, cable health, or queue times.
              </p>
            </div>

            {formError && (
              <div className="form-alert error-alert" role="alert">
                <AlertCircle size={16} />
                <span>{formError}</span>
              </div>
            )}

            {successMessage && (
              <div className="form-alert success-alert" role="status">
                <CheckCircle size={16} />
                <span>{successMessage}</span>
              </div>
            )}

            <form className="community-form" onSubmit={handleSubmit}>
              {/* Select Station */}
              <div className="form-group">
                <label htmlFor="form-select-station" className="form-label">
                  Select Charging Station <span className="req">*</span>
                </label>
                <select
                  id="form-select-station"
                  className="form-control-select"
                  value={stationId}
                  onChange={(e) => setStationId(e.target.value)}
                  required
                >
                  <option value="">-- Choose a station in Pune --</option>
                  {stations.map((st) => (
                    <option key={st.id} value={st.id}>
                      {st.name} ({st.area || "Pune"})
                    </option>
                  ))}
                </select>
              </div>

              {/* Status Radio / Pill Selector */}
              <div className="form-group">
                <label className="form-label">
                  Reported Availability <span className="req">*</span>
                </label>
                <div className="status-selector-grid">
                  <label
                    className={`status-option-card available ${
                      reportedStatus === "Available" ? "selected" : ""
                    }`}
                  >
                    <input
                      type="radio"
                      name="status"
                      value="Available"
                      checked={reportedStatus === "Available"}
                      onChange={() => setReportedStatus("Available")}
                    />
                    <CheckCircle size={18} />
                    <div className="status-label-group">
                      <strong>Available</strong>
                      <span>Chargers ready</span>
                    </div>
                  </label>

                  <label
                    className={`status-option-card occupied ${
                      reportedStatus === "Occupied" ? "selected" : ""
                    }`}
                  >
                    <input
                      type="radio"
                      name="status"
                      value="Occupied"
                      checked={reportedStatus === "Occupied"}
                      onChange={() => setReportedStatus("Occupied")}
                    />
                    <Clock size={18} />
                    <div className="status-label-group">
                      <strong>Occupied</strong>
                      <span>Cars in queue</span>
                    </div>
                  </label>

                  <label
                    className={`status-option-card broken ${
                      reportedStatus === "Out of Order" ? "selected" : ""
                    }`}
                  >
                    <input
                      type="radio"
                      name="status"
                      value="Out of Order"
                      checked={reportedStatus === "Out of Order"}
                      onChange={() => setReportedStatus("Out of Order")}
                    />
                    <AlertTriangle size={18} />
                    <div className="status-label-group">
                      <strong>Out of Order</strong>
                      <span>Fault / Offline</span>
                    </div>
                  </label>
                </div>
              </div>

              {/* Driver Name */}
              <div className="form-group">
                <label htmlFor="form-author-name" className="form-label">
                  Your Name / Handle <span className="text-muted">(Optional)</span>
                </label>
                <input
                  id="form-author-name"
                  type="text"
                  className="form-control-input"
                  placeholder="e.g. Atharv J. or Nexon EV Commuter"
                  value={authorName}
                  onChange={(e) => setAuthorName(e.target.value)}
                />
              </div>

              {/* Star Rating Interactive */}
              <div className="form-group">
                <label className="form-label">Experience Rating (1 to 5 Stars)</label>
                <div className="star-rating-picker" role="radiogroup" aria-label="Star rating">
                  {[1, 2, 3, 4, 5].map((star) => {
                    const isFilled = (hoverRating || starRating) >= star;
                    return (
                      <button
                        key={star}
                        type="button"
                        className={`star-pick-btn ${isFilled ? "filled" : ""}`}
                        onClick={() => setStarRating(star)}
                        onMouseEnter={() => setHoverRating(star)}
                        onMouseLeave={() => setHoverRating(0)}
                        aria-label={`${star} star${star > 1 ? "s" : ""}`}
                      >
                        <Star size={24} />
                      </button>
                    );
                  })}
                  <span className="star-current-text">{starRating} of 5 Stars</span>
                </div>
              </div>

              {/* Review / Comment */}
              <div className="form-group">
                <label htmlFor="form-comment-text" className="form-label">
                  Feedback / Operational Notes <span className="text-muted">(Optional)</span>
                </label>
                <textarea
                  id="form-comment-text"
                  className="form-control-textarea"
                  rows={4}
                  placeholder="Share details: Were both guns operational? Any parking fees or security checks? Good lighting at night?"
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                ></textarea>
              </div>

              {/* Submit Button */}
              <button type="submit" id="btn-submit-community-report" className="btn-submit-report">
                <Send size={16} />
                <span>Submit Report to Community</span>
              </button>
            </form>
          </div>

          {/* Right Column: Live Feed of Community Submissions */}
          <div className="community-feed-column">
            <div className="feed-header-bar">
              <div>
                <h3 className="feed-title">Recent Community Submissions</h3>
                <p className="feed-subtitle">
                  Showing {filteredSubmissions.length} volunteer updates stored in browser
                </p>
              </div>

              {/* Filter Submissions by Station */}
              <div className="feed-filter-wrap">
                <Filter size={14} className="filter-icon" />
                <select
                  id="select-feed-filter-station"
                  className="feed-filter-select"
                  value={selectedFilterStation}
                  onChange={(e) => setSelectedFilterStation(e.target.value)}
                  aria-label="Filter community reports by station"
                >
                  <option value="All">All Stations</option>
                  {stations.map((st) => (
                    <option key={st.id} value={st.id}>
                      {st.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Submissions List */}
            <div className="feed-cards-list">
              {filteredSubmissions.length === 0 ? (
                <div className="no-feed-entries">
                  <MessageSquare size={36} className="empty-feed-icon" />
                  <p>No community reviews found for this station filter yet.</p>
                </div>
              ) : (
                filteredSubmissions.map((entry) => (
                  <article key={entry.id} className="feed-card-item">
                    <div className="feed-card-top">
                      <div>
                        <h4 className="feed-station-name">{entry.stationName}</h4>
                        <span className="feed-author-tag">
                          Reported by <strong>{entry.author}</strong> • {entry.timestamp}
                        </span>
                      </div>

                      <span
                        className={`status-pill status-${entry.status
                          .toLowerCase()
                          .replace(/\s+/g, "-")}`}
                      >
                        {entry.status === "Available" && <CheckCircle size={13} />}
                        {entry.status === "Occupied" && <Clock size={13} />}
                        {entry.status === "Out of Order" && <AlertTriangle size={13} />}
                        {entry.status}
                      </span>
                    </div>

                    {entry.rating && (
                      <div className="feed-stars-row">
                        <span className="stars-icons">
                          {"★".repeat(entry.rating)}
                          {"☆".repeat(5 - entry.rating)}
                        </span>
                        <span className="rating-tag">{entry.rating}.0 / 5</span>
                      </div>
                    )}

                    {entry.comment && <p className="feed-comment-text">"{entry.comment}"</p>}

                    <div className="feed-card-footer">
                      <span className="feed-verified-badge">
                        <Sparkles size={12} /> Community-Submitted Data
                      </span>
                      <span className="storage-badge">Saved in LocalStorage</span>
                    </div>
                  </article>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
