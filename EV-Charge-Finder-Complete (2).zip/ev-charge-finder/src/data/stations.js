// Charging station dataset for EV Charge Finder
// Demo & Educational dataset around Pune, Maharashtra, India.
// Note: Mark all unverified information as demo data. Does not claim live charger availability.

export const initialStations = [
  {
    id: "station-1",
    name: "Tata Power EZ Charge",
    address: "Warje Flyover Junction, Near Mai Mangeshkar Hospital, Warje, Pune, Maharashtra 411058",
    area: "Warje",
    latitude: 18.4798,
    longitude: 73.8016,
    chargerType: "Fast", // Fast or Normal
    connectorTypes: ["CCS-2 (60 kW)", "Type-2 AC (22 kW)"],
    totalPoints: 4,
    reportedStatus: "Available", // Available, Occupied, Out of Order
    openingHours: "24/7 Open",
    facilities: ["Free Parking", "Restroom", "24/7 Security", "Cafe Nearby", "Illuminated Canopy"],
    rating: 4.6,
    reviewCount: 28,
    lastUpdated: "15 mins ago",
    pricing: "₹18.50 / kWh (Demo)",
    description:
      "High-speed Tata Power DC dual-gun fast charger conveniently located right off the Mumbai-Bengaluru Highway bypass in Warje. Features clean parking bays, illuminated canopy, and quick access to local refreshments.",
    isDemoData: true
  },
  {
    id: "station-2",
    name: "Public Fast Charger, Sutar Building",
    address: "Sutar Building, Near Kothrud Bus Stand, Karve Road, Kothrud, Pune, Maharashtra 411038",
    area: "Kothrud",
    latitude: 18.5074,
    longitude: 73.8077,
    chargerType: "Fast",
    connectorTypes: ["CCS-2 (50 kW)", "Bharat DC-001 (15 kW)"],
    totalPoints: 3,
    reportedStatus: "Occupied",
    openingHours: "06:00 AM - 11:30 PM",
    facilities: ["Covered Parking", "Seating Area", "Drinking Water", "Shops Nearby"],
    rating: 4.2,
    reviewCount: 19,
    lastUpdated: "35 mins ago",
    pricing: "₹16.00 / kWh (Demo)",
    description:
      "Municipal public EV fast charging station situated at Sutar Building, central Kothrud. High footfall location with commercial shops, dining spots, and public transport access nearby.",
    isDemoData: true
  },
  {
    id: "station-3",
    name: "Ather Grid Fast Charger, AJ Tower",
    address: "AJ Tower, Near Gandhi Bhavan Road, Dahanukar Colony, Kothrud, Pune, Maharashtra 411038",
    area: "Kothrud",
    latitude: 18.5020,
    longitude: 73.8145,
    chargerType: "Fast",
    connectorTypes: ["Ather Proprietary Fast (3.3 kW DC)", "Type-2 AC (7.4 kW)"],
    totalPoints: 4,
    reportedStatus: "Available",
    openingHours: "24/7 Open",
    facilities: ["2W Dedicated Bays", "CCTV Surveillance", "Coffee Vending", "Clean Restrooms"],
    rating: 4.8,
    reviewCount: 42,
    lastUpdated: "8 mins ago",
    pricing: "Free for Ather owners / ₹15/hr Demo",
    description:
      "Fast 2-wheeler and compatible EV charging point under Ather Grid at AJ Tower. Extremely popular among local college students and daily commuters traveling between Karve Road and Deccan.",
    isDemoData: true
  },
  {
    id: "station-4",
    name: "Jio-bp Pulse EV Charging Hub",
    address: "Karve Road, Near MMCOE & Cummins College, Karve Nagar, Pune, Maharashtra 411052",
    area: "Karve Nagar",
    latitude: 18.4912,
    longitude: 73.8185,
    chargerType: "Fast",
    connectorTypes: ["CCS-2 Dual Gun (60 kW)", "Type-2 AC (22 kW)"],
    totalPoints: 6,
    reportedStatus: "Available",
    openingHours: "24/7 Open",
    facilities: ["Restrooms", "Wild Bean Cafe", "Tyre Inflation", "EV Lounge", "Security"],
    rating: 4.7,
    reviewCount: 35,
    lastUpdated: "5 mins ago",
    pricing: "₹19.00 / kWh (Demo)",
    description:
      "Flagship Jio-bp Pulse fast charging center located right on Karve Road close to Marathwada Mitra Mandal's College of Engineering (MMCOE). Ample waiting space with cafe and clean facilities.",
    isDemoData: true
  },
  {
    id: "station-5",
    name: "Magenta ChargeGrid - Baner Hub",
    address: "Baner High Street, Near Balewadi Phata, Baner, Pune, Maharashtra 411045",
    area: "Baner",
    latitude: 18.5590,
    longitude: 73.7788,
    chargerType: "Normal",
    connectorTypes: ["Type-2 AC (11 kW)", "16A 3-Pin Socket"],
    totalPoints: 4,
    reportedStatus: "Available",
    openingHours: "07:00 AM - 11:00 PM",
    facilities: ["Shopping Mall Parking", "Dining Court", "Free Wi-Fi", "Wheelchair Accessible"],
    rating: 4.1,
    reviewCount: 14,
    lastUpdated: "1 hour ago",
    pricing: "₹14.50 / kWh (Demo)",
    description:
      "AC destination charger ideal for vehicle top-ups while shopping or dining on Baner High Street. Supported by ChargeGrid mobile app authentication.",
    isDemoData: true
  },
  {
    id: "station-6",
    name: "Statiq EV Multi-Point Station",
    address: "Phoenix Marketcity Parking B2, Viman Nagar, Pune, Maharashtra 411014",
    area: "Viman Nagar",
    latitude: 18.5679,
    longitude: 73.9143,
    chargerType: "Fast",
    connectorTypes: ["CCS-2 (120 kW Ultra-Fast)", "Type-2 AC (22 kW)"],
    totalPoints: 8,
    reportedStatus: "Occupied",
    openingHours: "10:00 AM - 11:00 PM",
    facilities: ["Mall Parking", "Food Court", "Restrooms", "CCTV", "Fire Safety"],
    rating: 4.5,
    reviewCount: 56,
    lastUpdated: "22 mins ago",
    pricing: "₹21.00 / kWh (Demo)",
    description:
      "High-capacity Statiq charging hub located inside the basement parking of Phoenix Marketcity. Features high-power DC guns for fast turnaround times.",
    isDemoData: true
  },
  {
    id: "station-7",
    name: "Zeon Charging Hub - Phase 1",
    address: "Rajiv Gandhi Infotech Park, Hinjawadi Phase 1, Pune, Maharashtra 411057",
    area: "Hinjawadi",
    latitude: 18.5913,
    longitude: 73.7389,
    chargerType: "Fast",
    connectorTypes: ["CCS-2 (50 kW)", "CHAdeMO (50 kW)"],
    totalPoints: 4,
    reportedStatus: "Out of Order",
    openingHours: "24/7 Open",
    facilities: ["IT Park Visitor Parking", "Security Desk", "Vending Machines"],
    rating: 3.8,
    reviewCount: 21,
    lastUpdated: "2 hours ago",
    pricing: "₹18.00 / kWh (Demo)",
    description:
      "Convenient commuter charging hub situated at Hinjawadi IT Park. Note: Currently reported under maintenance for hardware upgrade. Check community reports.",
    isDemoData: true
  },
  {
    id: "station-8",
    name: "Fortum Charge & Drive",
    address: "Senapati Bapat Road, Near Pavillion Mall, Shivajinagar, Pune, Maharashtra 411016",
    area: "Shivajinagar",
    latitude: 18.5308,
    longitude: 73.8288,
    chargerType: "Normal",
    connectorTypes: ["Type-2 AC (22 kW)", "Bharat AC-001 (10 kW)"],
    totalPoints: 2,
    reportedStatus: "Available",
    openingHours: "24/7 Open",
    facilities: ["Valet Parking Available", "Restaurants Nearby", "ATM", "Clean Restrooms"],
    rating: 4.4,
    reviewCount: 16,
    lastUpdated: "45 mins ago",
    pricing: "₹15.00 / kWh (Demo)",
    description:
      "Centrally placed AC charging spot on Senapati Bapat Road. Reliable choice for daytime office visitors and shoppers visiting The Pavillion.",
    isDemoData: true
  }
];

// Initial demo community reports and reviews to populate localStorage
export const initialCommunitySubmissions = [
  {
    id: "sub-1",
    stationId: "station-1",
    stationName: "Tata Power EZ Charge (Warje)",
    author: "Atharv Jagtap",
    status: "Available",
    rating: 5,
    comment: "Both CCS2 guns were working smoothly. Charged my Nexon EV from 25% to 80% in 45 mins. Clean area.",
    timestamp: "2026-10-09 18:20",
    verifiedStatus: "Community Reported"
  },
  {
    id: "sub-2",
    stationId: "station-2",
    stationName: "Public Fast Charger, Sutar Building (Kothrud)",
    author: "Rohan Patil",
    status: "Occupied",
    rating: 4,
    comment: "A cab was plugged into gun 1 and another vehicle was waiting in line. Expect roughly 20-30 mins wait time.",
    timestamp: "2026-10-09 17:45",
    verifiedStatus: "Community Reported"
  },
  {
    id: "sub-3",
    stationId: "station-3",
    stationName: "Ather Grid Fast Charger, AJ Tower (Kothrud)",
    author: "Parthraj Malave",
    status: "Available",
    rating: 5,
    comment: "Fast charging works great on Ather 450X. Good lighting even at late evening.",
    timestamp: "2026-10-09 16:30",
    verifiedStatus: "Community Reported"
  },
  {
    id: "sub-4",
    stationId: "station-7",
    stationName: "Zeon Charging Hub - Phase 1 (Hinjawadi)",
    author: "Atharv Kakade",
    status: "Out of Order",
    rating: 2,
    comment: "Screen displays error code E-14 on gun 2. Gun 1 cable connector is locked. Avoid until technician fixes it.",
    timestamp: "2026-10-09 15:10",
    verifiedStatus: "Community Reported"
  }
];
