import { initialCommunitySubmissions } from "../data/stations";

const STORAGE_KEY = "ev_charge_finder_submissions_v1";

/**
 * Retrieve submissions from localStorage or fall back to sample entries
 */
export function getStoredSubmissions() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      // Seed with default initial demonstration data
      localStorage.setItem(STORAGE_KEY, JSON.stringify(initialCommunitySubmissions));
      return initialCommunitySubmissions;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : initialCommunitySubmissions;
  } catch (err) {
    console.warn("Could not read from localStorage, using in-memory demo data:", err);
    return initialCommunitySubmissions;
  }
}

/**
 * Save new report / review submission
 */
export function addSubmission(submission) {
  try {
    const current = getStoredSubmissions();
    const updated = [submission, ...current];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return updated;
  } catch (err) {
    console.error("Failed to save submission to localStorage:", err);
    return [];
  }
}

/**
 * Format date nicely for human display
 */
export function formatTimestamp(date = new Date()) {
  const d = new Date(date);
  const pad = (n) => String(n).padStart(2, "0");
  const year = d.getFullYear();
  const month = pad(d.getMonth() + 1);
  const day = pad(d.getDate());
  const hours = pad(d.getHours());
  const minutes = pad(d.getMinutes());
  return `${year}-${month}-${day} ${hours}:${minutes}`;
}
