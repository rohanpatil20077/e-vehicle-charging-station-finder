import React from "react";
import {
  Zap,
  MapPin,
  Clock,
  Star,
  Navigation,
  ExternalLink,
  CheckCircle,
  AlertTriangle,
  Info
} from "lucide-react";
import { getDirectionsUrl } from "../utils/geoUtils";

export default function StationCard({
  station,
  isSelected,
  onSelect,
  onViewDetails,
  userLocation
}) {
  const directionsUrl = getDirectionsUrl(
    station.latitude,
    station.longitude,
    userLocation?.latitude,
    userLocation?.longitude
  );

  const getStatusClass = (status) => {
    switch (status) {
      case "Available":
        return "status-badge available";
      case "Occupied":
        return "status-badge occupied";
      case "Out of Order":
        return "status-badge broken";
      default:
        return "status-badge";
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case "Available":
        return <CheckCircle size={13} />;
      case "Occupied":
        return <Clock size={13} />;
      case "Out of Order":
        return <AlertTriangle size={13} />;
      default:
        return <Info size={13} />;
    }
  };

  return (
    <article
      id={`station-card-${station.id}`}
      className={`station-card ${isSelected ? "selected" : ""}`}
      onClick={() => onSelect(station)}
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          onSelect(station);
        }
      }}
      aria-label={`Charging station ${station.name}`}
    >
      <div className="card-top">
        <div className="card-status-row">
          <span className={getStatusClass(station.reportedStatus)}>
            {getStatusIcon(station.reportedStatus)}
            {station.reportedStatus}
          </span>

          <span className={`charger-badge ${station.chargerType.toLowerCase()}`}>
            <Zap size={13} />
            {station.chargerType} Charger
          </span>

          {station.distance != null && (
            <span className="distance-badge" title="Estimated distance from your location">
              <Navigation size={12} /> {station.distance} km away
            </span>
          )}
        </div>

        <h3 className="station-title">{station.name}</h3>

        <p className="station-address">
          <MapPin size={15} className="icon-subtle" />
          <span>{station.address}</span>
        </p>
      </div>

      <div className="card-specs">
        <div className="spec-item">
          <span className="spec-label">Total Ports</span>
          <span className="spec-val">
            <strong>{station.totalPoints}</strong> bays
          </span>
        </div>

        <div className="spec-item">
          <span className="spec-label">Hours</span>
          <span className="spec-val">
            <Clock size={12} className="inline-icon" /> {station.openingHours}
          </span>
        </div>

        <div className="spec-item">
          <span className="spec-label">Rating</span>
          <span className="spec-val rating-val">
            <Star size={13} className="star-icon" /> {station.rating}{" "}
            <small>({station.reviewCount || 0})</small>
          </span>
        </div>
      </div>

      {station.facilities && station.facilities.length > 0 && (
        <div className="card-facilities">
          {station.facilities.slice(0, 3).map((facility, i) => (
            <span key={i} className="facility-tag">
              {facility}
            </span>
          ))}
          {station.facilities.length > 3 && (
            <span className="facility-tag more">+{station.facilities.length - 3}</span>
          )}
        </div>
      )}

      <div className="card-footer">
        <span className="last-updated-text">Updated {station.lastUpdated}</span>

        <div className="card-actions" onClick={(e) => e.stopPropagation()}>
          <button
            type="button"
            className="btn-card-details"
            onClick={() => onViewDetails(station)}
            aria-label={`View full details for ${station.name}`}
          >
            View Details
          </button>

          <a
            href={directionsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-card-directions"
            title="Open directions in OpenStreetMap"
            aria-label={`Get directions to ${station.name} in OpenStreetMap`}
          >
            <Navigation size={14} />
            Directions
            <ExternalLink size={12} />
          </a>
        </div>
      </div>
    </article>
  );
}
