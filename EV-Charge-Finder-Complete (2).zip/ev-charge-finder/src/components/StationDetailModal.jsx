import React from "react";
import {
  X,
  MapPin,
  Clock,
  Zap,
  Star,
  Navigation,
  ExternalLink,
  ShieldAlert,
  CheckCircle,
  AlertTriangle,
  MessageSquarePlus,
  Layers,
  Sparkles
} from "lucide-react";
import { getDirectionsUrl } from "../utils/geoUtils";

export default function StationDetailModal({
  station,
  onClose,
  userLocation,
  onOpenCommunityReport,
  communitySubmissions = []
}) {
  if (!station) return null;

  const directionsUrl = getDirectionsUrl(
    station.latitude,
    station.longitude,
    userLocation?.latitude,
    userLocation?.longitude
  );

  // Filter community reports specifically for this station
  const stationReports = communitySubmissions.filter(
    (item) => item.stationId === station.id
  );

  return (
    <div className="modal-backdrop" onClick={onClose} role="dialog" aria-modal="true">
      <div
        className="modal-container station-detail-modal"
        onClick={(e) => e.stopPropagation()}
        tabIndex={-1}
      >
        {/* Modal Header */}
        <div className="modal-header">
          <div className="header-titles">
            <span className="station-type-tag">
              <Zap size={14} /> {station.chargerType} Charging Station
            </span>
            <h2 className="modal-title">{station.name}</h2>
            <p className="modal-subaddress">
              <MapPin size={15} className="inline-icon" /> {station.address}
            </p>
          </div>

          <button
            type="button"
            className="btn-modal-close"
            onClick={onClose}
            aria-label="Close station details"
          >
            <X size={20} />
          </button>
        </div>

        {/* Modal Content Scrollable */}
        <div className="modal-body">
          {/* Important Educational / Demo Data Disclaimer Banner */}
          <div className="demo-disclaimer-banner">
            <ShieldAlert size={20} className="banner-icon" />
            <div>
              <strong>Academic Project & Community Demonstration Data</strong>
              <p>
                Status reported below is derived from volunteer community updates and demo project
                benchmarks. This system does not claim real-time hardware telemetry feeds from
                utility operators.
              </p>
            </div>
          </div>

          {/* Quick Status Bar */}
          <div className="station-highlight-grid">
            <div className="highlight-card">
              <span className="highlight-label">Reported Status</span>
              <div className={`status-pill status-${station.reportedStatus.toLowerCase().replace(/\s+/g, "-")}`}>
                {station.reportedStatus === "Available" && <CheckCircle size={14} />}
                {station.reportedStatus === "Occupied" && <Clock size={14} />}
                {station.reportedStatus === "Out of Order" && <AlertTriangle size={14} />}
                <span>{station.reportedStatus}</span>
              </div>
            </div>

            <div className="highlight-card">
              <span className="highlight-label">Charging Bays</span>
              <span className="highlight-value">
                <strong>{station.totalPoints}</strong> Points Available
              </span>
            </div>

            <div className="highlight-card">
              <span className="highlight-label">Operating Schedule</span>
              <span className="highlight-value">{station.openingHours}</span>
            </div>

            <div className="highlight-card">
              <span className="highlight-label">Rating (Sample)</span>
              <span className="highlight-value rating-text">
                <Star size={16} className="star-filled" /> {station.rating} / 5.0
              </span>
            </div>
          </div>

          {/* Station Description */}
          <div className="section-block">
            <h4 className="section-heading">Overview</h4>
            <p className="station-description-text">{station.description}</p>
          </div>

          {/* Connectors & Pricing */}
          <div className="section-block grid-two-col">
            <div className="sub-panel">
              <h4 className="section-heading">Supported Connectors</h4>
              <ul className="connectors-list">
                {station.connectorTypes?.map((c, idx) => (
                  <li key={idx} className="connector-item">
                    <Zap size={14} className="bolt-green" />
                    <span>{c}</span>
                  </li>
                )) || <li>Standard Compatible EV Ports</li>}
              </ul>
            </div>

            <div className="sub-panel">
              <h4 className="section-heading">Tariff & Last Update</h4>
              <p className="pricing-info">
                <strong>Estimated Tariff:</strong> {station.pricing || "₹18.00 / kWh"}
              </p>
              <p className="update-info">
                <strong>Last Updated:</strong> {station.lastUpdated}
              </p>
              <p className="coords-info">
                <strong>Coordinates:</strong> {station.latitude.toFixed(4)}° N, {station.longitude.toFixed(4)}° E
              </p>
            </div>
          </div>

          {/* Facilities */}
          {station.facilities && (
            <div className="section-block">
              <h4 className="section-heading">Amenities & Facilities</h4>
              <div className="facilities-wrap">
                {station.facilities.map((fac, idx) => (
                  <span key={idx} className="facility-badge">
                    <Sparkles size={12} className="spark-icon" /> {fac}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Community Reports for this station */}
          <div className="section-block community-reports-preview">
            <div className="community-header-row">
              <h4 className="section-heading">
                Community Reports & Feedback ({stationReports.length})
              </h4>
              <button
                type="button"
                className="btn-quick-report"
                onClick={() => {
                  onClose();
                  onOpenCommunityReport(station.id);
                }}
              >
                <MessageSquarePlus size={15} />
                Report Status / Review
              </button>
            </div>

            {stationReports.length === 0 ? (
              <p className="no-reports-msg">
                No visitor reports filed yet for this station today. Be the first to submit a status!
              </p>
            ) : (
              <div className="reports-mini-list">
                {stationReports.map((report) => (
                  <div key={report.id} className="report-mini-card">
                    <div className="report-mini-head">
                      <strong>{report.author || "Anonymous Driver"}</strong>
                      <span className={`status-pill-small status-${report.status.toLowerCase().replace(/\s+/g, "-")}`}>
                        {report.status}
                      </span>
                      <span className="report-time">{report.timestamp}</span>
                    </div>
                    {report.rating && (
                      <div className="report-stars">
                        {"★".repeat(report.rating)}
                        {"☆".repeat(5 - report.rating)}
                      </div>
                    )}
                    {report.comment && <p className="report-comment">{report.comment}</p>}
                    <span className="report-badge-source">Community Verified</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Modal Footer Actions */}
        <div className="modal-footer">
          <a
            href={directionsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-primary-directions"
          >
            <Navigation size={16} />
            <span>Open Directions in OpenStreetMap</span>
            <ExternalLink size={14} />
          </a>

          <button type="button" className="btn-secondary-close" onClick={onClose}>
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
