import React, { useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { ExternalLink, Navigation, Zap, AlertTriangle, Clock, CheckCircle } from "lucide-react";
import { getDirectionsUrl } from "../utils/geoUtils";

// Helper component to smoothly center/fly map when selectedStation or userCoords change
function MapController({ center, zoom, selectedStation }) {
  const map = useMap();

  useEffect(() => {
    if (selectedStation) {
      map.flyTo([selectedStation.latitude, selectedStation.longitude], 15, {
        duration: 1.2
      });
    } else if (center) {
      map.flyTo(center, zoom || 13, { duration: 1.0 });
    }
  }, [center, zoom, selectedStation, map]);

  return null;
}

// Generate premium custom SVG marker pins
function createCustomPin(status, isSelected = false) {
  let bgColor = "#10b981"; // Emerald Green
  let iconSvg = `<path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" fill="white"/>`; // Lightning bolt
  let shadowColor = "rgba(16, 185, 129, 0.4)";

  if (status === "Occupied") {
    bgColor = "#f59e0b"; // Amber
    shadowColor = "rgba(245, 158, 11, 0.4)";
    iconSvg = `<circle cx="12" cy="12" r="8" fill="none" stroke="white" stroke-width="2.5"/><path d="M12 7v5l3 3" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round"/>`;
  } else if (status === "Out of Order") {
    bgColor = "#ef4444"; // Red
    shadowColor = "rgba(239, 68, 68, 0.4)";
    iconSvg = `<path d="M12 8v5M12 16h.01" fill="none" stroke="white" stroke-width="3" stroke-linecap="round"/><circle cx="12" cy="12" r="9" fill="none" stroke="white" stroke-width="2.5"/>`;
  }

  const borderStyle = isSelected ? "border: 3px solid #ffffff; box-shadow: 0 0 0 3px #0f172a, 0 10px 20px " + shadowColor : "border: 2px solid #ffffff; box-shadow: 0 4px 14px " + shadowColor;
  const transformScale = isSelected ? "transform: scale(1.15);" : "";

  const html = `
    <div style="
      position: relative;
      width: 38px;
      height: 48px;
      display: flex;
      flex-direction: column;
      align-items: center;
      ${transformScale}
      transition: all 0.2s ease-in-out;
      cursor: pointer;
    ">
      <div style="
        width: 36px;
        height: 36px;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        background: ${bgColor};
        display: flex;
        align-items: center;
        justify-content: center;
        ${borderStyle}
      ">
        <svg style="transform: rotate(45deg); width: 18px; height: 18px;" viewBox="0 0 24 24">
          ${iconSvg}
        </svg>
      </div>
      <div style="
        width: 8px;
        height: 4px;
        background: rgba(15, 23, 42, 0.4);
        border-radius: 50%;
        margin-top: 4px;
        filter: blur(1px);
      "></div>
    </div>
  `;

  return L.divIcon({
    html,
    className: "custom-station-pin",
    iconSize: [38, 48],
    iconAnchor: [19, 44],
    popupAnchor: [0, -42]
  });
}

// User location marker
function createUserLocationPin() {
  const html = `
    <div style="position: relative; width: 28px; height: 28px; display: flex; align-items: center; justify-content: center;">
      <div style="position: absolute; width: 28px; height: 28px; border-radius: 50%; background: rgba(14, 165, 233, 0.35); animation: pulse-ring 2s infinite ease-out;"></div>
      <div style="width: 16px; height: 16px; border-radius: 50%; background: #0284c7; border: 3px solid #ffffff; box-shadow: 0 2px 6px rgba(0,0,0,0.3);"></div>
    </div>
  `;
  return L.divIcon({
    html,
    className: "user-location-pin",
    iconSize: [28, 28],
    iconAnchor: [14, 14],
    popupAnchor: [0, -14]
  });
}

export default function StationMap({
  stations,
  selectedStation,
  onSelectStation,
  onViewDetails,
  userLocation,
  center = [18.5089, 73.8185], // Center around Kothrud/Karve Nagar/Warje Pune
  zoom = 13
}) {
  return (
    <div className="map-container-wrapper" id="ev-interactive-map">
      <MapContainer
        center={center}
        zoom={zoom}
        scrollWheelZoom={true}
        className="leaflet-map-element"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        <MapController center={center} zoom={zoom} selectedStation={selectedStation} />

        {/* User Location Marker */}
        {userLocation && (
          <Marker
            position={[userLocation.latitude, userLocation.longitude]}
            icon={createUserLocationPin()}
          >
            <Popup className="premium-popup">
              <div className="popup-inner">
                <div className="popup-header-user">
                  <Navigation size={14} className="user-icon" />
                  <strong>Your Current Location</strong>
                </div>
                <p className="popup-user-note">Showing distance to charging stations.</p>
              </div>
            </Popup>
          </Marker>
        )}

        {/* Charging Station Markers */}
        {stations.map((st) => {
          const isSelected = selectedStation?.id === st.id;
          const pinIcon = createCustomPin(st.reportedStatus, isSelected);

          return (
            <Marker
              key={st.id}
              position={[st.latitude, st.longitude]}
              icon={pinIcon}
              eventHandlers={{
                click: () => {
                  onSelectStation(st);
                }
              }}
            >
              <Popup className="premium-popup">
                <div className="popup-card">
                  <div className="popup-header">
                    <span className={`status-pill status-${st.reportedStatus.toLowerCase().replace(/\s+/g, "-")}`}>
                      {st.reportedStatus === "Available" && <CheckCircle size={12} />}
                      {st.reportedStatus === "Occupied" && <Clock size={12} />}
                      {st.reportedStatus === "Out of Order" && <AlertTriangle size={12} />}
                      {st.reportedStatus}
                    </span>
                    <span className="type-badge-mini">
                      <Zap size={11} /> {st.chargerType}
                    </span>
                  </div>

                  <h4 className="popup-title">{st.name}</h4>
                  <p className="popup-address">{st.address}</p>

                  <div className="popup-metrics">
                    <span className="metric-item">
                      <strong>Points:</strong> {st.totalPoints}
                    </span>
                    <span className="metric-item">
                      <strong>Rating:</strong> ★ {st.rating}
                    </span>
                  </div>

                  <div className="popup-actions">
                    <button
                      type="button"
                      className="btn-popup-details"
                      onClick={() => onViewDetails(st)}
                    >
                      View Details
                    </button>
                    <a
                      href={getDirectionsUrl(
                        st.latitude,
                        st.longitude,
                        userLocation?.latitude,
                        userLocation?.longitude
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="btn-popup-directions"
                      title="Open directions in OpenStreetMap"
                    >
                      <Navigation size={13} />
                      Directions
                      <ExternalLink size={11} />
                    </a>
                  </div>
                </div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>

      {/* Map Legend Overlay */}
      <div className="map-legend">
        <span className="legend-title">Station Status</span>
        <div className="legend-items">
          <div className="legend-item">
            <span className="legend-dot dot-available"></span> Available
          </div>
          <div className="legend-item">
            <span className="legend-dot dot-occupied"></span> Occupied
          </div>
          <div className="legend-item">
            <span className="legend-dot dot-broken"></span> Out of Order
          </div>
        </div>
      </div>
    </div>
  );
}
