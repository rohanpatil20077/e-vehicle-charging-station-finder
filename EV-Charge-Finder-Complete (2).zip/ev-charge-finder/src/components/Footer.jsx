import React from "react";
import { BatteryCharging, Heart, ShieldCheck, MapPin, GraduationCap, Users } from "lucide-react";

export default function Footer({ setActivePage }) {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="site-footer" id="main-footer">
      <div className="container footer-top-grid">
        {/* Brand & Mission */}
        <div className="footer-col brand-col">
          <div className="footer-logo">
            <div className="logo-icon-wrap-sm">
              <BatteryCharging size={20} className="logo-icon-svg" />
            </div>
            <span className="brand-name">
              EV Charge <span className="highlight-text">Finder</span>
            </span>
          </div>

          <p className="footer-desc">
            An open educational platform helping electric vehicle drivers locate verified charging stations,
            view community-reported availability, and navigate cleanly across Pune.
          </p>

          <div className="college-tag">
            <GraduationCap size={16} />
            <span>MMCOE, Karve Nagar, Pune</span>
          </div>
        </div>

        {/* Quick Navigation */}
        <div className="footer-col">
          <h4 className="footer-title">Navigation</h4>
          <ul className="footer-links">
            <li>
              <button type="button" onClick={() => setActivePage("home")}>
                Home
              </button>
            </li>
            <li>
              <button type="button" onClick={() => setActivePage("find")}>
                Find Chargers
              </button>
            </li>
            <li>
              <button type="button" onClick={() => setActivePage("community")}>
                Community Reports
              </button>
            </li>
            <li>
              <button type="button" onClick={() => setActivePage("about")}>
                About Project
              </button>
            </li>
          </ul>
        </div>

        {/* Key Pune Areas */}
        <div className="footer-col">
          <h4 className="footer-title">Demo Coverage (Pune)</h4>
          <ul className="footer-links-static">
            <li>
              <MapPin size={13} /> Warje & Mai Mangeshkar
            </li>
            <li>
              <MapPin size={13} /> Kothrud (Sutar Bldg & AJ Tower)
            </li>
            <li>
              <MapPin size={13} /> Karve Nagar & Cummins
            </li>
            <li>
              <MapPin size={13} /> Baner High Street
            </li>
            <li>
              <MapPin size={13} /> Hinjawadi IT Park & Viman Nagar
            </li>
          </ul>
        </div>

        {/* Project Attribution */}
        <div className="footer-col project-credits-col">
          <h4 className="footer-title">Academic Details</h4>
          <p className="project-detail">
            <strong>Project:</strong> E-Vehicle Charging Station Finder
          </p>
          <p className="project-detail">
            <strong>Institute:</strong> Marathwada Mitra Mandal's College of Engineering (MMCOE)
          </p>
          <p className="project-detail">
            <strong>Location:</strong> Karve Nagar, Pune - 411052
          </p>
          <p className="project-detail">
            <strong>Dept:</strong> Information Technology
          </p>
          <p className="project-detail">
            <strong>Project Guide:</strong> Mrs. S. P. Vanjari
          </p>
        </div>
      </div>

      {/* Team Members Strip */}
      <div className="container footer-team-strip">
        <div className="team-strip-inner">
          <div className="team-lead-label">
            <Users size={16} />
            <span>Project Team:</span>
          </div>
          <div className="team-chips">
            <span className="team-chip">Atharv Shyam Jagtap</span>
            <span className="team-chip">Atharv Vilas Kakade</span>
            <span className="team-chip">Parthraj Vaibhav Malave</span>
            <span className="team-chip">Rohan Pravin Patil</span>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="footer-bottom-bar">
        <div className="container bottom-bar-inner">
          <p className="disclaimer-text">
            <ShieldCheck size={14} className="inline-icon" />
            Notice: Educational prototype created at MMCOE, Pune. Charger statuses reflect sample &
            volunteer community reports, not real-time utility telemetry.
          </p>
          <p className="copyright-text">
            © {currentYear} EV Charge Finder • Built for green mobility.
          </p>
        </div>
      </div>
    </footer>
  );
}
