import React, { useState } from "react";
import { Zap, MapPin, Users, Info, Menu, X, BatteryCharging, User, LogIn, CheckCircle } from "lucide-react";

export default function Navbar({ activePage, setActivePage, currentUser }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: "home", label: "Home", icon: Zap },
    { id: "find", label: "Find Chargers", icon: MapPin },
    { id: "community", label: "Community", icon: Users },
    { id: "about", label: "About", icon: Info }
  ];

  const handleNavClick = (id) => {
    setActivePage(id);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <header className="site-header" id="main-navigation">
      <div className="header-inner container">
        {/* Brand / Logo */}
        <button
          type="button"
          className="brand-logo"
          onClick={() => handleNavClick("home")}
          aria-label="EV Charge Finder Homepage"
        >
          <div className="logo-icon-wrap">
            <BatteryCharging size={22} className="logo-icon-svg" />
          </div>
          <div className="brand-text-wrap">
            <span className="brand-name">
              EV Charge <span className="highlight-text">Finder</span>
            </span>
            <span className="brand-sub">Pune Green Mobility</span>
          </div>
        </button>

        {/* Desktop Navigation Links */}
        <nav className="desktop-nav" aria-label="Main Navigation">
          <ul className="nav-list">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activePage === item.id;
              return (
                <li key={item.id}>
                  <button
                    type="button"
                    className={`nav-link-btn ${isActive ? "active" : ""}`}
                    onClick={() => handleNavClick(item.id)}
                    aria-current={isActive ? "page" : undefined}
                  >
                    <Icon size={16} />
                    <span>{item.label}</span>
                  </button>
                </li>
              );
            })}
          </ul>

          <div className="header-right-actions">
            {/* User Account / Login Button */}
            {currentUser ? (
              <button
                type="button"
                className={`btn-user-avatar-pill ${activePage === "login" ? "active" : ""}`}
                onClick={() => handleNavClick("login")}
                title={`Logged in as ${currentUser.name}`}
              >
                <div className="nav-avatar-circle">
                  {currentUser.name
                    .split(" ")
                    .map((n) => n[0])
                    .slice(0, 2)
                    .join("")}
                </div>
                <span className="nav-user-name">{currentUser.name.split(" ")[0]}</span>
              </button>
            ) : (
              <button
                type="button"
                className={`btn-nav-login ${activePage === "login" ? "active" : ""}`}
                onClick={() => handleNavClick("login")}
              >
                <LogIn size={15} />
                <span>Sign In</span>
              </button>
            )}

            <button
              type="button"
              className="btn-header-cta"
              onClick={() => handleNavClick("find")}
            >
              <MapPin size={16} />
              <span>Locate Chargers</span>
            </button>
          </div>
        </nav>

        {/* Mobile Hamburger Button */}
        <button
          type="button"
          className="mobile-menu-toggle"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-expanded={mobileMenuOpen}
          aria-label="Toggle navigation menu"
        >
          {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="mobile-nav-drawer" role="navigation">
          <ul className="mobile-nav-list">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activePage === item.id;
              return (
                <li key={item.id}>
                  <button
                    type="button"
                    className={`mobile-nav-item ${isActive ? "active" : ""}`}
                    onClick={() => handleNavClick(item.id)}
                  >
                    <Icon size={18} />
                    <span>{item.label}</span>
                  </button>
                </li>
              );
            })}

            {/* Mobile Auth Button */}
            <li>
              <button
                type="button"
                className={`mobile-nav-item ${activePage === "login" ? "active" : ""}`}
                onClick={() => handleNavClick("login")}
              >
                {currentUser ? (
                  <>
                    <User size={18} className="text-emerald" />
                    <span>My Account ({currentUser.name})</span>
                  </>
                ) : (
                  <>
                    <LogIn size={18} />
                    <span>Sign In / Register</span>
                  </>
                )}
              </button>
            </li>
          </ul>

          <div className="mobile-drawer-cta">
            <button
              type="button"
              className="btn-header-cta w-full"
              onClick={() => handleNavClick("find")}
            >
              <MapPin size={16} />
              <span>Locate Chargers Now</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
