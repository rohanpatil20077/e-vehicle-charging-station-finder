import React from "react";
import {
  Search,
  Filter,
  RotateCcw,
  Navigation,
  Loader2,
  Check,
  X
} from "lucide-react";

export default function SearchFilters({
  searchTerm,
  setSearchTerm,
  chargerTypeFilter,
  setChargerTypeFilter,
  statusFilter,
  setStatusFilter,
  maxDistance,
  setMaxDistance,
  sortBy,
  setSortBy,
  userLocation,
  isLocating,
  locationError,
  onGetLocation,
  onClearFilters,
  totalResults,
  totalStations
}) {
  const isFiltered =
    searchTerm !== "" ||
    chargerTypeFilter !== "All" ||
    statusFilter !== "All" ||
    maxDistance !== "All" ||
    sortBy !== "default";

  return (
    <div className="search-filters-panel" id="filter-controls-section">
      {/* Top Search Input & Geolocation Button */}
      <div className="search-bar-row">
        <div className="search-input-wrapper">
          <Search size={18} className="search-icon" />
          <input
            id="station-search-input"
            type="text"
            className="search-input"
            placeholder="Search city, area, or station name (e.g. Kothrud, Warje, Tata Power)..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            aria-label="Search stations by name or area"
          />
          {searchTerm && (
            <button
              type="button"
              className="btn-clear-search"
              onClick={() => setSearchTerm("")}
              aria-label="Clear search text"
            >
              <X size={16} />
            </button>
          )}
        </div>

        <button
          type="button"
          id="btn-use-my-location"
          className={`btn-geolocation ${userLocation ? "active" : ""}`}
          onClick={onGetLocation}
          disabled={isLocating}
          title={
            userLocation
              ? "Location detected: Click to refresh"
              : "Detect your location for nearest chargers"
          }
          aria-label="Use my location to find nearby stations"
        >
          {isLocating ? (
            <>
              <Loader2 size={16} className="spin-icon" />
              <span>Locating...</span>
            </>
          ) : userLocation ? (
            <>
              <Check size={16} className="text-success" />
              <span>Location Active</span>
            </>
          ) : (
            <>
              <Navigation size={16} />
              <span>Use My Location</span>
            </>
          )}
        </button>
      </div>

      {locationError && (
        <div className="location-error-alert" role="alert">
          <span>{locationError}</span>
        </div>
      )}

      {/* Filter Chips / Dropdowns Row */}
      <div className="filter-controls-row">
        {/* Charger Type Filter */}
        <div className="filter-group">
          <label htmlFor="select-charger-type" className="filter-label">
            Charger Type
          </label>
          <div className="pill-options" id="select-charger-type">
            {["All", "Fast", "Normal"].map((type) => (
              <button
                key={type}
                type="button"
                className={`pill-btn ${chargerTypeFilter === type ? "selected" : ""}`}
                onClick={() => setChargerTypeFilter(type)}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {/* Status Filter */}
        <div className="filter-group">
          <label htmlFor="select-status-filter" className="filter-label">
            Availability
          </label>
          <select
            id="select-status-filter"
            className="filter-select"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
          >
            <option value="All">All Statuses</option>
            <option value="Available">Available Only</option>
            <option value="Occupied">Occupied</option>
            <option value="Out of Order">Out of Order</option>
          </select>
        </div>

        {/* Distance Filter (Available when location is on) */}
        <div className="filter-group">
          <label htmlFor="select-distance-filter" className="filter-label">
            Distance {userLocation ? `(km)` : "(Enable GPS)"}
          </label>
          <select
            id="select-distance-filter"
            className="filter-select"
            value={maxDistance}
            onChange={(e) => setMaxDistance(e.target.value)}
            disabled={!userLocation}
          >
            <option value="All">Any Distance</option>
            <option value="5">Within 5 km</option>
            <option value="10">Within 10 km</option>
            <option value="15">Within 15 km</option>
          </select>
        </div>

        {/* Sort By Filter */}
        <div className="filter-group">
          <label htmlFor="select-sort-filter" className="filter-label">
            Sort By
          </label>
          <select
            id="select-sort-filter"
            className="filter-select"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
          >
            <option value="default">Default Recommended</option>
            {userLocation && <option value="nearest">Nearest Station First</option>}
            <option value="rating">Highest Rated</option>
            <option value="points">Most Charging Bays</option>
          </select>
        </div>
      </div>

      {/* Meta Bar: Results counter + Clear button */}
      <div className="filters-meta-row">
        <div className="results-counter">
          <Filter size={14} className="filter-icon" />
          <span>
            Showing <strong>{totalResults}</strong> of {totalStations} stations
          </span>
          {userLocation && <span className="location-hint">• Proximity enabled</span>}
        </div>

        {isFiltered && (
          <button
            type="button"
            id="btn-clear-filters"
            className="btn-clear-filters"
            onClick={onClearFilters}
            aria-label="Clear all applied search filters"
          >
            <RotateCcw size={14} />
            Clear Filters
          </button>
        )}
      </div>
    </div>
  );
}
