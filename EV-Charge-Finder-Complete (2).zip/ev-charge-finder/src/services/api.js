// API Client Service for EV Charge Finder
// Connects to Node.js/Express REST API with resilient fallback to LocalStorage/local dataset.

import { initialStations } from "../data/stations";
import { getStoredSubmissions, addSubmission } from "../utils/storageUtils";

const API_BASE = "/api";
const AUTH_USER_KEY = "ev_charge_finder_auth_user_v1";

// Demo fallback users for standalone client mode
const DEMO_FALLBACK_USERS = [
  {
    id: "user-1",
    email: "driver@evfinder.com",
    password: "password123",
    name: "Atharv Jagtap",
    vehicle: "Tata Nexon EV (Max)",
    role: "EV Commuter"
  },
  {
    id: "user-2",
    email: "rohan@mmcoe.edu.in",
    password: "password123",
    name: "Rohan Patil",
    vehicle: "Ather 450X Gen 3",
    role: "Student Contributor"
  }
];

/**
 * Check if Express REST API backend is reachable
 */
export async function checkBackendStatus() {
  try {
    const res = await fetch(`${API_BASE}/health`, { method: "GET" });
    if (!res.ok) throw new Error("Health check failed");
    const data = await res.json();
    return { isOnline: true, data };
  } catch (err) {
    return { isOnline: false, error: err.message };
  }
}

/**
 * Fetch stations from Express Backend (or fallback to local data)
 */
export async function getStations(params = {}) {
  try {
    const query = new URLSearchParams();
    if (params.search) query.append("search", params.search);
    if (params.chargerType && params.chargerType !== "All") query.append("chargerType", params.chargerType);
    if (params.status && params.status !== "All") query.append("status", params.status);
    if (params.lat != null && params.lng != null) {
      query.append("lat", params.lat);
      query.append("lng", params.lng);
    }

    const url = `${API_BASE}/stations${query.toString() ? "?" + query.toString() : ""}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    return { stations: json.data || [], isFromBackend: true };
  } catch (err) {
    console.warn("Backend unavailable, using client dataset:", err.message);
    return { stations: initialStations, isFromBackend: false };
  }
}

/**
 * Fetch all community reports from Backend (or fallback to localStorage)
 */
export async function getReports(stationId = null) {
  try {
    const url = stationId ? `${API_BASE}/reports?stationId=${encodeURIComponent(stationId)}` : `${API_BASE}/reports`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();
    return { reports: json.data || [], isFromBackend: true };
  } catch (err) {
    console.warn("Backend unavailable, using LocalStorage for reports:", err.message);
    const local = getStoredSubmissions();
    const filtered = stationId ? local.filter((r) => r.stationId === stationId) : local;
    return { reports: filtered, isFromBackend: false };
  }
}

/**
 * Submit community report to Backend REST API (with LocalStorage backup)
 */
export async function postReport(reportData) {
  const localUpdated = addSubmission(reportData);

  try {
    const res = await fetch(`${API_BASE}/reports`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(reportData)
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || `HTTP ${res.status}`);
    }

    const json = await res.json();
    return {
      success: true,
      report: json.report,
      updatedStation: json.updatedStation,
      isFromBackend: true
    };
  } catch (err) {
    console.warn("Failed to reach backend, stored in local storage:", err.message);
    return {
      success: true,
      report: reportData,
      isFromBackend: false,
      note: "Saved in LocalStorage (Offline Mode)"
    };
  }
}

// ----------------- AUTHENTICATION HELPERS -----------------

/**
 * Get active user from browser storage
 */
export function getStoredUser() {
  try {
    const raw = localStorage.getItem(AUTH_USER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

/**
 * Set active user in browser storage
 */
export function setStoredUser(user) {
  if (user) {
    localStorage.setItem(AUTH_USER_KEY, JSON.stringify(user));
  } else {
    localStorage.removeItem(AUTH_USER_KEY);
  }
}

/**
 * Login user via backend API (or fallback to demo credentials)
 */
export async function loginUser(email, password) {
  try {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || "Login failed");
    }

    setStoredUser(data.user);
    return { success: true, user: data.user, isFromBackend: true };
  } catch (err) {
    // Check fallback demo users if backend is offline
    const matched = DEMO_FALLBACK_USERS.find(
      (u) => u.email.toLowerCase() === email.trim().toLowerCase() && u.password === password
    );

    if (matched) {
      const { password: _, ...safe } = matched;
      setStoredUser(safe);
      return { success: true, user: safe, isFromBackend: false };
    }

    throw new Error(err.message || "Invalid credentials.");
  }
}

/**
 * Register user via backend API (or fallback to local session)
 */
export async function registerUser({ name, email, password, vehicle }) {
  try {
    const res = await fetch(`${API_BASE}/auth/register`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, password, vehicle })
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || "Registration failed");
    }

    setStoredUser(data.user);
    return { success: true, user: data.user, isFromBackend: true };
  } catch (err) {
    // If backend offline, create client user
    if (err.message && !err.message.includes("fetch")) {
      throw err;
    }

    const localUser = {
      id: `user-${Date.now()}`,
      email: email.trim().toLowerCase(),
      name: name.trim(),
      vehicle: vehicle?.trim() || "Electric Vehicle",
      role: "EV Driver",
      createdAt: new Date().toISOString().substring(0, 10)
    };

    setStoredUser(localUser);
    return { success: true, user: localUser, isFromBackend: false };
  }
}

/**
 * Logout user
 */
export function logoutUser() {
  setStoredUser(null);
  return { success: true };
}
