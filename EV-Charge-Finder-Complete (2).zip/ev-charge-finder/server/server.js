import express from "express";
import cors from "cors";
import fs from "fs/promises";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_PATH = path.join(__dirname, "data", "db.json");

const app = express();
const PORT = process.env.PORT || 5000;

// Enable CORS and JSON parsing
app.use(cors());
app.use(express.json());

// Request logger middleware
app.use((req, res, next) => {
  console.log(`[API ${new Date().toISOString().substring(11, 19)}] ${req.method} ${req.originalUrl}`);
  next();
});

// Helper: Read database from db.json
async function readDb() {
  try {
    const raw = await fs.readFile(DB_PATH, "utf-8");
    return JSON.parse(raw);
  } catch (err) {
    console.error("Error reading db.json:", err);
    throw new Error("Database read error");
  }
}

// Helper: Write database to db.json
async function writeDb(data) {
  try {
    await fs.writeFile(DB_PATH, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Error writing db.json:", err);
    throw new Error("Database write error");
  }
}

// Helper: Haversine distance in km
function calculateDistance(lat1, lon1, lat2, lon2) {
  if (lat1 == null || lon1 == null || lat2 == null || lon2 == null) return null;
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

// ---------------- API ROUTES ----------------

// 1. Health & Server Info
app.get("/api/health", (req, res) => {
  res.json({
    status: "healthy",
    uptimeSeconds: Math.floor(process.uptime()),
    timestamp: new Date().toISOString(),
    service: "EV Charge Finder REST API (Pune)",
    environment: process.env.NODE_ENV || "development"
  });
});

// 2. GET /api/stations - List all stations with optional search, filters & distance calculation
app.get("/api/stations", async (req, res, next) => {
  try {
    const db = await readDb();
    let stations = db.stations || [];

    const { search, chargerType, status, lat, lng } = req.query;
    const userLat = lat ? parseFloat(lat) : null;
    const userLng = lng ? parseFloat(lng) : null;

    // Attach calculated distance if user coordinates provided
    if (userLat != null && userLng != null && !isNaN(userLat) && !isNaN(userLng)) {
      stations = stations.map((st) => ({
        ...st,
        distance: calculateDistance(userLat, userLng, st.latitude, st.longitude)
      }));
    }

    // Filter by search query
    if (search && search.trim() !== "") {
      const q = search.toLowerCase().trim();
      stations = stations.filter(
        (st) =>
          st.name.toLowerCase().includes(q) ||
          st.address.toLowerCase().includes(q) ||
          (st.area && st.area.toLowerCase().includes(q)) ||
          (st.description && st.description.toLowerCase().includes(q))
      );
    }

    // Filter by charger type (Fast, Normal)
    if (chargerType && chargerType !== "All") {
      stations = stations.filter((st) => st.chargerType === chargerType);
    }

    // Filter by status (Available, Occupied, Out of Order)
    if (status && status !== "All") {
      stations = stations.filter((st) => st.reportedStatus === status);
    }

    res.json({
      success: true,
      count: stations.length,
      data: stations
    });
  } catch (err) {
    next(err);
  }
});

// 3. GET /api/stations/:id - Single station details with its community reports
app.get("/api/stations/:id", async (req, res, next) => {
  try {
    const db = await readDb();
    const station = db.stations.find((s) => s.id === req.params.id);

    if (!station) {
      return res.status(404).json({
        success: false,
        error: `Station with ID "${req.params.id}" not found.`
      });
    }

    const stationReports = (db.reports || []).filter((r) => r.stationId === req.params.id);

    res.json({
      success: true,
      data: {
        ...station,
        reports: stationReports
      }
    });
  } catch (err) {
    next(err);
  }
});

// 4. GET /api/reports - All community reports
app.get("/api/reports", async (req, res, next) => {
  try {
    const db = await readDb();
    let reports = db.reports || [];

    if (req.query.stationId) {
      reports = reports.filter((r) => r.stationId === req.query.stationId);
    }

    res.json({
      success: true,
      count: reports.length,
      data: reports
    });
  } catch (err) {
    next(err);
  }
});

// 5. POST /api/reports - Submit new report with sensible input validation & state update
app.post("/api/reports", async (req, res, next) => {
  try {
    const { stationId, status, author, comment, rating } = req.body;

    // Validation 1: Required Station ID
    if (!stationId) {
      return res.status(400).json({
        success: false,
        error: "Validation error: stationId is required."
      });
    }

    // Validation 2: Status check
    const validStatuses = ["Available", "Occupied", "Out of Order"];
    if (!status || !validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        error: `Validation error: status must be one of: ${validStatuses.join(", ")}.`
      });
    }

    // Validation 3: Rating check (1 - 5)
    const numericRating = rating ? parseInt(rating, 10) : 5;
    if (isNaN(numericRating) || numericRating < 1 || numericRating > 5) {
      return res.status(400).json({
        success: false,
        error: "Validation error: rating must be an integer between 1 and 5."
      });
    }

    const db = await readDb();
    const stationIndex = db.stations.findIndex((s) => s.id === stationId);

    if (stationIndex === -1) {
      return res.status(404).json({
        success: false,
        error: `Station with ID "${stationId}" not found in database.`
      });
    }

    const matchedStation = db.stations[stationIndex];
    const pad = (n) => String(n).padStart(2, "0");
    const now = new Date();
    const timestampStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}`;

    // Create report entry
    const newReport = {
      id: `sub-${Date.now()}`,
      stationId,
      stationName: matchedStation.name,
      author: (author && author.trim()) || "Anonymous Driver",
      status,
      rating: numericRating,
      comment: (comment && comment.trim()) || "",
      timestamp: timestampStr,
      verifiedStatus: "Community Reported"
    };

    // Update station reported status & timestamp
    matchedStation.reportedStatus = status;
    matchedStation.lastUpdated = "Just now (REST API)";

    // Update review count & rating average responsibly
    const existingReports = (db.reports || []).filter((r) => r.stationId === stationId);
    const newTotalReviews = existingReports.length + 1;
    const sumRatings = existingReports.reduce((acc, r) => acc + (r.rating || 5), 0) + numericRating;
    matchedStation.rating = Math.round((sumRatings / newTotalReviews) * 10) / 10;
    matchedStation.reviewCount = (matchedStation.reviewCount || 0) + 1;

    // Save changes
    db.reports.unshift(newReport);
    db.stations[stationIndex] = matchedStation;
    await writeDb(db);

    res.status(201).json({
      success: true,
      message: `Report for ${matchedStation.name} saved successfully.`,
      report: newReport,
      updatedStation: matchedStation
    });
  } catch (err) {
    next(err);
  }
});

// ---------------- AUTHENTICATION ROUTES ----------------

// 6. POST /api/auth/login - User login with credential validation
app.post("/api/auth/login", async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        error: "Email and password are required."
      });
    }

    const db = await readDb();
    const users = db.users || [];
    const normalizedEmail = email.trim().toLowerCase();

    const user = users.find(
      (u) => u.email.toLowerCase() === normalizedEmail && u.password === password
    );

    if (!user) {
      return res.status(401).json({
        success: false,
        error: "Invalid email or password. Please try again or use the demo login."
      });
    }

    // Strip password before returning
    const { password: _, ...safeUser } = user;
    const token = `token-${safeUser.id}-${Date.now()}`;

    res.json({
      success: true,
      message: `Welcome back, ${safeUser.name}!`,
      user: safeUser,
      token
    });
  } catch (err) {
    next(err);
  }
});

// 7. POST /api/auth/register - Create new user account
app.post("/api/auth/register", async (req, res, next) => {
  try {
    const { name, email, password, vehicle } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({
        success: false,
        error: "Name is required."
      });
    }

    if (!email || !email.includes("@")) {
      return res.status(400).json({
        success: false,
        error: "Valid email address is required."
      });
    }

    if (!password || password.length < 6) {
      return res.status(400).json({
        success: false,
        error: "Password must be at least 6 characters long."
      });
    }

    const db = await readDb();
    db.users = db.users || [];
    const normalizedEmail = email.trim().toLowerCase();

    const existingUser = db.users.find(
      (u) => u.email.toLowerCase() === normalizedEmail
    );

    if (existingUser) {
      return res.status(409).json({
        success: false,
        error: "An account with this email address already exists. Please log in instead."
      });
    }

    const newUser = {
      id: `user-${Date.now()}`,
      email: normalizedEmail,
      password: password,
      name: name.trim(),
      vehicle: (vehicle && vehicle.trim()) || "Electric Vehicle",
      role: "EV Driver",
      createdAt: new Date().toISOString().substring(0, 10)
    };

    db.users.push(newUser);
    await writeDb(db);

    const { password: _, ...safeUser } = newUser;
    const token = `token-${safeUser.id}-${Date.now()}`;

    res.status(201).json({
      success: true,
      message: `Account created successfully. Welcome, ${safeUser.name}!`,
      user: safeUser,
      token
    });
  } catch (err) {
    next(err);
  }
});

// 8. GET /api/auth/demo-users - Helper for testers/faculty
app.get("/api/auth/demo-users", async (req, res, next) => {
  try {
    const db = await readDb();
    const users = (db.users || []).map(({ password, ...u }) => ({
      ...u,
      demoPasswordHint: "password123"
    }));

    res.json({
      success: true,
      demoUsers: users
    });
  } catch (err) {
    next(err);
  }
});


// 404 Route handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: `Cannot ${req.method} ${req.originalUrl}. Route not found.`
  });
});

// Centralized error handling middleware
app.use((err, req, res, next) => {
  console.error("API Error:", err);
  res.status(500).json({
    success: false,
    error: "Internal Server Error",
    message: err.message
  });
});

// Start Express server if run directly
if (process.env.NODE_ENV !== "test") {
  app.listen(PORT, () => {
    console.log(`⚡ EV Charge Finder Backend REST API running at: http://localhost:${PORT}`);
    console.log(`📡 Health Check endpoint: http://localhost:${PORT}/api/health`);
    console.log(`🔌 Stations endpoint: http://localhost:${PORT}/api/stations`);
  });
}

export default app;
