// Quick verification test for backend API endpoints
async function testApi() {
  try {
    const healthRes = await fetch("http://localhost:5000/api/health");
    const health = await healthRes.json();
    console.log("✓ Health Check Passed:", health.status);

    const stationsRes = await fetch("http://localhost:5000/api/stations?chargerType=Fast");
    const stations = await stationsRes.json();
    console.log("✓ Fast Stations Query Passed: Count =", stations.count);

    const postRes = await fetch("http://localhost:5000/api/reports", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        stationId: "station-1",
        status: "Available",
        author: "Atharv Jagtap (MMCOE)",
        rating: 5,
        comment: "Tested via Express REST API. Guns 1 and 2 active."
      })
    });
    const postData = await postRes.json();
    console.log("✓ POST /api/reports Passed:", postData.success, postData.report?.author);

    const singleRes = await fetch("http://localhost:5000/api/stations/station-1");
    const singleData = await singleRes.json();
    console.log("✓ GET /api/stations/:id Passed: Reports attached =", singleData.data.reports?.length);
    console.log("ALL BACKEND API TESTS COMPLETED SUCCESSFULLY!");
  } catch (err) {
    console.error("Test failed:", err);
    process.exit(1);
  }
}

testApi();
